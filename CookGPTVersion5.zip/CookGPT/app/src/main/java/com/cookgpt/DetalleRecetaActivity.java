package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.room.Room;

public class DetalleRecetaActivity extends AppCompatActivity {
    TextView txtNombre, txtPasos, txtTiempo;

    private AppDatabase db;
    private Receta recetaActual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_receta);

        txtNombre = findViewById(R.id.txtNombre);
        txtPasos = findViewById(R.id.txtPasos);
        txtTiempo = findViewById(R.id.txtTiempo);

        // Inicializar DB (igual que en MainActivity)
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        String nombre = getIntent().getStringExtra("nombre");
        String pasos = getIntent().getStringExtra("pasos");
        int tiempo = getIntent().getIntExtra("tiempo", 0);

        // Cargar la receta desde Room por nombre (sin tocar otras pantallas)
        if (nombre != null) {
            recetaActual = db.recetaDao().getByNombre(nombre);
        }

        if (recetaActual == null) {
            // Fallback: si por alguna razón no se encontró, crear una "vista" temporal
            recetaActual = new Receta();
            recetaActual.nombre = nombre != null ? nombre : "Receta";
            recetaActual.pasos = pasos != null ? pasos : "";
            recetaActual.tiempo = tiempo;
            recetaActual.favorita = false;
        } else {
            // Priorizar datos de DB si existen
            if (pasos == null) pasos = recetaActual.pasos;
            if (tiempo == 0) tiempo = recetaActual.tiempo;
        }

        txtPasos.setText("Pasos: " + (pasos != null ? pasos : ""));
        txtTiempo.setText("Tiempo: " + tiempo + " min");

        // Pintar encabezado con estrella segun favorito
        renderTitulo();

        // Al tocar el título, alterna favorito
        txtNombre.setOnClickListener(v -> {
            if (recetaActual.id == 0) {
                Toast.makeText(this, "No se pudo guardar favorito (receta sin id).", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean nuevo = !recetaActual.favorita;
            db.recetaDao().updateFavorita(recetaActual.id, nuevo);
            recetaActual.favorita = nuevo;
            renderTitulo();
            Toast.makeText(this, nuevo ? "Añadida a favoritos" : "Quitada de favoritos", Toast.LENGTH_SHORT).show();
        });
    }

    private void renderTitulo() {
        String estrella = (recetaActual != null && recetaActual.favorita) ? " ★" : " ☆";
        String nombreMostrado = (recetaActual != null && recetaActual.nombre != null) ? recetaActual.nombre : "Receta";
        txtNombre.setText("Receta: " + nombreMostrado + estrella);
    }
}
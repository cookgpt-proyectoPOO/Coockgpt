package com.cookgpt;

public class HistorialRecetaDao {
}

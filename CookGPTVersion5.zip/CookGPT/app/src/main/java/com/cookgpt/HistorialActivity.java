package com.cookgpt;

import android.app.Activity;

public class HistorialActivity extends Activity {
}

package com.cookgpt;

import java.util.List;

/**
 * GestorUtensilios: Clase controladora que maneja la lógica de negocio de utensilios.
 *
 * PRINCIPIO DE POO APLICADO:
 * - Separación de Responsabilidades: Maneja solo utensilios
 * - DRY (Don't Repeat Yourself): Evita duplicar código en diferentes Activities
 */
public class GestorUtensilios {

    private UtensilioDao utensilioDao;

    /**
     * Constructor
     */
    public GestorUtensilios(UtensilioDao utensilioDao) {
        this.utensilioDao = utensilioDao;
    }



    /**
     * Obtiene todos los utensilios
     */
    public List<Utensilio> obtenerTodos() {
        return utensilioDao.getAll();
    }

    /**
     * Obtiene solo los utensilios disponibles
     */
    public List<Utensilio> obtenerDisponibles() {
        return utensilioDao.getDisponibles();
    }

    /**
     * Busca un utensilio por nombre
     */
    public Utensilio buscarPorNombre(String nombre) {
        if (nombre == null) return null;

        String nombreBuscado = nombre.toLowerCase().trim();
        List<Utensilio> todos = utensilioDao.getAll();

        for (Utensilio ut : todos) {
            if (ut.getNombre().toLowerCase().trim().equals(nombreBuscado)) {
                return ut;
            }
        }

        return null;
    }

    /**
     * Verifica si un utensilio existe
     */
    public boolean existe(String nombre) {
        return buscarPorNombre(nombre) != null;
    }



    /**
     * Agrega un nuevo utensilio
     */
    public String agregarUtensilio(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre no puede estar vacío";
        }

        Utensilio existente = buscarPorNombre(nombre);

        if (existente != null) {
            return "Este utensilio ya existe";
        } else {
            Utensilio nuevo = new Utensilio(nombre.toLowerCase().trim(), false);
            utensilioDao.insertar(nuevo);
            return "Utensilio agregado: " + nombre;
        }
    }

    /**
     * Marca un utensilio como disponible
     */
    public void marcarDisponible(Utensilio utensilio) {
        if (utensilio != null) {
            utensilio.marcarDisponible();
            utensilioDao.actualizar(utensilio);
        }
    }

    /**
     * Marca un utensilio como no disponible
     */
    public void marcarNoDisponible(Utensilio utensilio) {
        if (utensilio != null) {
            utensilio.marcarNoDisponible();
            utensilioDao.actualizar(utensilio);
        }
    }

    /**
     * Alterna la disponibilidad de un utensilio
     */
    public void alternarDisponibilidad(Utensilio utensilio) {
        if (utensilio != null) {
            utensilio.alternarDisponibilidad();
            utensilioDao.actualizar(utensilio);
        }
    }



    /**
     * Verifica si hay utensilios guardados
     */
    public boolean hayUtensiliosGuardados() {
        List<Utensilio> utensilios = utensilioDao.getAll();
        return utensilios != null && !utensilios.isEmpty();
    }

    /**
     * Inicializa utensilios básicos si la base está vacía
     */
    public void inicializarUtensiliosBasicos() {
        if (!hayUtensiliosGuardados()) {
            String[] nombresUtensilios = {
                    "sarten", "olla", "microondas", "batidora", "cuchillo",
                    "tabla de cortar", "tenedor", "cuchara", "cazo", "espatula",
                    "tazon", "licuadora", "pinzas"
            };

            for (String nombre : nombresUtensilios) {
                Utensilio u = new Utensilio(nombre, false);
                utensilioDao.insertar(u);
            }
        }
    }



    /**
     * Genera un texto formateado con la lista de utensilios
     */
    public String generarLista() {
        List<Utensilio> utensilios = obtenerTodos();
        StringBuilder sb = new StringBuilder();

        if (utensilios.isEmpty()) {
            sb.append("No hay utensilios registrados");
        } else {
            for (Utensilio ut : utensilios) {
                sb.append(ut.obtenerRepresentacion()).append("\n");
            }
        }

        return sb.toString();
    }

    /**
     * Obtiene la cantidad de utensilios disponibles
     */
    public int contarDisponibles() {
        return obtenerDisponibles().size();
    }
}

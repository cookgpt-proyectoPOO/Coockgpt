package com.cookgpt;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

/**
 * GestorIngredientes: Clase controladora que maneja la lógica de negocio de ingredientes.
 *
 * PRINCIPIO DE POO APLICADO:
 * - Separación de Responsabilidades: Esta clase solo maneja ingredientes
 * - Reutilización: Puede ser usada en diferentes Activities sin duplicar código
 */
public class GestorIngredientes {

    private IngredienteDao ingredienteDao;

    /**
     * Constructor
     */
    public GestorIngredientes(IngredienteDao ingredienteDao) {
        this.ingredienteDao = ingredienteDao;
    }



    /**
     * Obtiene todos los ingredientes
     */
    public List<Ingrediente> obtenerTodos() {
        return ingredienteDao.getAll();
    }

    /**
     * Obtiene solo los ingredientes disponibles
     */
    public List<Ingrediente> obtenerDisponibles() {
        return ingredienteDao.getDisponibles();
    }

    /**
     * Busca un ingrediente por nombre (normalizado)
     */
    public Ingrediente buscarPorNombre(String nombre) {
        String nombreNormalizado = normalizarTexto(nombre);
        List<Ingrediente> todos = ingredienteDao.getAll();

        for (Ingrediente ing : todos) {
            if (normalizarTexto(ing.getNombre()).equals(nombreNormalizado)) {
                return ing;
            }
        }

        return null;
    }

    /**
     * Verifica si un ingrediente ya existe en la base de datos
     */
    public boolean existe(String nombre) {
        return buscarPorNombre(nombre) != null;
    }



    /**
     * Agrega un nuevo ingrediente o activa uno existente
     * RETORNA: mensaje descriptivo del resultado
     */
    public String agregarIngrediente(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre no puede estar vacío";
        }

        String nombreNormalizado = normalizarTexto(nombre);
        Ingrediente existente = buscarPorNombre(nombreNormalizado);

        if (existente != null) {
            // El ingrediente ya existe
            if (!existente.isDisponible()) {
                // Estaba desactivado, lo activamos
                existente.marcarDisponible();
                ingredienteDao.actualizar(existente);
                return "Ingrediente activado: " + existente.getNombre();
            } else {
                return "Este ingrediente ya existe y está disponible";
            }
        } else {
            // Es un ingrediente nuevo
            Ingrediente nuevo = new Ingrediente(nombreNormalizado, true);
            ingredienteDao.insertar(nuevo);
            return "Ingrediente guardado: " + nombreNormalizado;
        }
    }

    /**
     * Marca un ingrediente como disponible
     */
    public void marcarDisponible(Ingrediente ingrediente) {
        if (ingrediente != null) {
            ingrediente.marcarDisponible();
            ingredienteDao.actualizar(ingrediente);
        }
    }

    /**
     * Marca un ingrediente como no disponible
     */
    public void marcarNoDisponible(Ingrediente ingrediente) {
        if (ingrediente != null) {
            ingrediente.marcarNoDisponible();
            ingredienteDao.actualizar(ingrediente);
        }
    }

    /**
     * Alterna la disponibilidad de un ingrediente
     */
    public void alternarDisponibilidad(Ingrediente ingrediente) {
        if (ingrediente != null) {
            ingrediente.alternarDisponibilidad();
            ingredienteDao.actualizar(ingrediente);
        }
    }



    /**
     * Genera un texto formateado con la lista de ingredientes disponibles
     */
    public String generarListaDisponibles() {
        List<Ingrediente> ingredientes = obtenerTodos();
        StringBuilder sb = new StringBuilder("Ingredientes disponibles:\n");

        if (ingredientes.isEmpty()) {
            sb.append("No hay ingredientes registrados");
        } else {
            boolean hayDisponibles = false;
            for (Ingrediente ing : ingredientes) {
                if (ing.isDisponible()) {
                    sb.append("✓ ").append(ing.getNombre()).append("\n");
                    hayDisponibles = true;
                }
            }

            if (!hayDisponibles) {
                sb.append("No hay ingredientes marcados como disponibles");
            }
        }

        return sb.toString();
    }



    /**
     * Normaliza el texto: elimina acentos, convierte a minúsculas y elimina espacios extras
     * Este método centraliza la lógica de normalización que antes estaba en MainActivity
     */
    private String normalizarTexto(String texto) {
        if (texto == null) return "";


        texto = texto.toLowerCase();


        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");


        texto = texto.trim().replaceAll("\\s+", " ");

        return texto;
    }

    /**
     * Obtiene la cantidad de ingredientes disponibles
     */
    public int contarDisponibles() {
        return obtenerDisponibles().size();
    }

    /**
     * Verifica si hay suficientes ingredientes para hacer alguna receta
     */
    public boolean haySuficientesIngredientes(int minimo) {
        return contarDisponibles() >= minimo;
    }
}

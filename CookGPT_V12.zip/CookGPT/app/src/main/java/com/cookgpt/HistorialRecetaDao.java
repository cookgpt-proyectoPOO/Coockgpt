package com.cookgpt;

import androidx.room.*;
import java.util.List;

/**
 * HistorialRecetaDao: DAO para acceder a la tabla de historial de recetas.
 */
@Dao
public interface HistorialRecetaDao {

    @Insert
    void insertar(HistorialReceta historial);

    @Query("SELECT * FROM HistorialReceta WHERE username = :username ORDER BY fechaVista ASC")
    List<HistorialReceta> obtenerPorUsuario(String username);

    @Query("DELETE FROM HistorialReceta WHERE username = :username")
    void eliminarPorUsuario(String username);

    @Query("SELECT * FROM HistorialReceta")
    List<HistorialReceta> getAll();

    @Query("DELETE FROM HistorialReceta")
    void eliminarTodo();
}
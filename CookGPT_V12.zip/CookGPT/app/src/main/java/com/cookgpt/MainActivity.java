package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import androidx.room.Room;
import android.content.Intent;

/**
 * MainActivity: Pantalla principal de la aplicación CookGPT.
 * AHORA con sistema de autenticación integrado.
 */
public class MainActivity extends AppCompatActivity {


    private EditText input;
    private Button btnGuardar, btnUtensilios, btnSugerencias, btnCerrarSesion, btnAdmin, btnHistorial;
    private TextView lista, txtBienvenida;


    private GestorIngredientes gestorIngredientes;
    private GestorRecetas gestorRecetas;
    private GestorUtensilios gestorUtensilios;
    private SesionManager sesionManager;


    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        sesionManager = new SesionManager(this);


        if (!sesionManager.hayUsuarioLogueado()) {
            irALogin();
            return;
        }

        setContentView(R.layout.activity_main);

        inicializarBaseDatos();
        inicializarGestores();
        conectarElementosUI();
        inicializarDatos();
        configurarListeners();
        mostrarInfoUsuario();
        mostrarIngredientes();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestores() {
        gestorIngredientes = new GestorIngredientes(db.ingredienteDao());
        gestorRecetas = new GestorRecetas(db.recetaDao());
        gestorUtensilios = new GestorUtensilios(db.utensilioDao());
    }

    private void conectarElementosUI() {
        txtBienvenida = findViewById(R.id.txtBienvenida);
        input = findViewById(R.id.inputIngrediente);
        btnGuardar = findViewById(R.id.btnGuardar);
        lista = findViewById(R.id.txtLista);
        btnUtensilios = findViewById(R.id.btnUtensilios);
        btnSugerencias = findViewById(R.id.btnSugerencias);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        btnAdmin = findViewById(R.id.btnAdmin);
        btnHistorial = findViewById(R.id.btnHistorial);


        if (sesionManager.esAdministrador()) {
            btnAdmin.setVisibility(android.view.View.VISIBLE);
        } else {
            btnAdmin.setVisibility(android.view.View.GONE);
        }
    }

    private void inicializarDatos() {
        gestorRecetas.inicializarRecetasDeEjemplo();
        gestorUtensilios.inicializarUtensiliosBasicos();
    }

    private void configurarListeners() {
        btnGuardar.setOnClickListener(v -> guardarIngrediente());
        btnUtensilios.setOnClickListener(v -> irAUtensilios());
        btnSugerencias.setOnClickListener(v -> irASugerencias());
        btnCerrarSesion.setOnClickListener(v -> cerrarSesion());
        btnAdmin.setOnClickListener(v -> irAPanelAdmin());
        btnHistorial.setOnClickListener(v -> irAHistorial());
    }

    /**
     * Muestra información del usuario logueado
     */
    private void mostrarInfoUsuario() {
        String username = sesionManager.getUsername();
        String rol = sesionManager.esAdministrador() ? " 👨‍💼 (Admin)" : " 👤";
        txtBienvenida.setText("Bienvenido, " + username + rol);
    }

    private void guardarIngrediente() {
        String nombre = input.getText().toString().trim();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa un ingrediente", Toast.LENGTH_SHORT).show();
            return;
        }

        String resultado = gestorIngredientes.agregarIngrediente(nombre);
        Toast.makeText(this, resultado, Toast.LENGTH_SHORT).show();
        mostrarIngredientes();
        input.setText("");
    }

    private void mostrarIngredientes() {
        String listaFormateada = gestorIngredientes.generarListaDisponibles();
        lista.setText(listaFormateada);
    }

    private void irAUtensilios() {
        Intent intent = new Intent(MainActivity.this, UtensiliosActivity.class);
        startActivity(intent);
    }

    private void irASugerencias() {
        Intent intent = new Intent(MainActivity.this, SugerenciasActivity.class);
        startActivity(intent);
    }

    /**
     * Cierra la sesión y vuelve al login
     */
    private void cerrarSesion() {
        sesionManager.cerrarSesion();
        Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show();
        irALogin();
    }

    /**
     * Abre el panel de administración (solo para admins)
     */
    private void irAPanelAdmin() {
        Intent intent = new Intent(MainActivity.this, AdminActivity.class);
        startActivity(intent);
    }

    /**
     * Navega a la pantalla de login
     */
    private void irALogin() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();


        if (!sesionManager.hayUsuarioLogueado()) {
            irALogin();
            return;
        }

        mostrarIngredientes();
    }
    /**
     * Navega a la pantalla de historial
     */
    private void irAHistorial() {
        Intent intent = new Intent(MainActivity.this, HistorialActivity.class);
        startActivity(intent);
    }
}
package com.cookgpt;

import android.content.Context;
import android.content.SharedPreferences;

public class SesionManager {

    private static final String PREF_NAME = "CookGPTSesion";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_IS_ADMIN = "isAdmin";

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private Context context;

    public SesionManager(Context context) {
        this.context = context;
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void iniciarSesion(Usuario usuario) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putInt(KEY_USER_ID, usuario.getId());
        editor.putString(KEY_USERNAME, usuario.getUsername());
        editor.putBoolean(KEY_IS_ADMIN, usuario.isEsAdministrador());
        editor.apply();
    }

    public void cerrarSesion() {
        editor.clear();
        editor.apply();
    }

    public boolean hayUsuarioLogueado() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public int getUsuarioId() {
        return prefs.getInt(KEY_USER_ID, -1);
    }

    public String getUsername() {
        return prefs.getString(KEY_USERNAME, null);
    }

    public boolean esAdministrador() {
        return prefs.getBoolean(KEY_IS_ADMIN, false);
    }

    public void actualizarRolAdmin(boolean esAdmin) {
        editor.putBoolean(KEY_IS_ADMIN, esAdmin);
        editor.apply();
    }

    public String obtenerInfoSesion() {
        if (!hayUsuarioLogueado()) {
            return "No hay sesión activa";
        }

        String rol = esAdministrador() ? "Administrador" : "Usuario";
        return String.format("Usuario: %s\nRol: %s", getUsername(), rol);
    }
}
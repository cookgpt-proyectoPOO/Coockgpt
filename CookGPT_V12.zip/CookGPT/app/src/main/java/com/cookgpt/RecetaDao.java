package com.cookgpt;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface RecetaDao {
    @Insert
    void insertar(Receta r);

    @Query("SELECT * FROM Receta")
    List<Receta> getAll();


    @Query("SELECT * FROM Receta WHERE nombre = :nombre LIMIT 1")
    Receta getByNombre(String nombre);


    @Query("UPDATE Receta SET favorita = :favorita WHERE id = :id")
    void updateFavorita(int id, boolean favorita);


    @Query("SELECT * FROM Receta WHERE favorita = 1")
    List<Receta> getFavoritas();
}
package com.cookgpt;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Clase Receta: Representa una receta de cocina con todos sus atributos y comportamientos.
 *
 * PRINCIPIOS DE POO APLICADOS:
 * - Encapsulación: Los atributos son privados y se accede mediante getters/setters
 * - Responsabilidad única: Esta clase maneja todo lo relacionado con UNA receta
 * - Comportamiento: Incluye métodos que definen qué puede hacer una receta
 */
@Entity
public class Receta {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String nombre;
    private String ingredientes;  // Formato: "ingrediente1,ingrediente2,ingrediente3"
    private String utensiliosNecesarios;  // Formato: "utensilio1,utensilio2"
    private String pasos;
    private int tiempo;  // En minutos
    private boolean favorita;
    private String informacionNutricional;  // Formato: "Calorías: X, Proteínas: Y, Carbohidratos: Z, Grasas: W"



    /**
     * Constructor vacío requerido por Room Database
     */
    public Receta() {
        this.favorita = false;
    }

    /**
     * Constructor completo para crear una receta nueva
     */
    public Receta(String nombre, String ingredientes, String utensiliosNecesarios,
                  String pasos, int tiempo) {
        this.nombre = nombre;
        this.ingredientes = ingredientes;
        this.utensiliosNecesarios = utensiliosNecesarios;
        this.pasos = pasos;
        this.tiempo = tiempo;
        this.favorita = false;
    }



    /**
     * Verifica si esta receta se puede preparar con los ingredientes disponibles
     * ANTES: Este método estaba en SugerenciasActivity
     * AHORA: Está en la clase Receta porque es responsabilidad de la receta saber
     *        si puede ser preparada o no
     */
    public boolean sePuedePreparar(List<String> ingredientesDisponibles,
                                   List<String> utensiliosDisponibles) {
        return tieneIngredientesNecesarios(ingredientesDisponibles) &&
                tieneUtensiliosNecesarios(utensiliosDisponibles);
    }

    /**
     * Verifica si todos los ingredientes necesarios están disponibles
     */
    private boolean tieneIngredientesNecesarios(List<String> ingredientesDisponibles) {
        if (this.ingredientes == null || this.ingredientes.isEmpty()) {
            return false;
        }

        List<String> necesarios = obtenerListaIngredientes();

        for (String ingrediente : necesarios) {
            if (!ingredientesDisponibles.contains(ingrediente.toLowerCase().trim())) {
                return false;
            }
        }

        return true;
    }

    /**
     * Verifica si todos los utensilios necesarios están disponibles
     */
    private boolean tieneUtensiliosNecesarios(List<String> utensiliosDisponibles) {
        if (this.utensiliosNecesarios == null || this.utensiliosNecesarios.isEmpty()) {
            return true;  // Si no necesita utensilios, siempre se puede hacer
        }

        List<String> necesarios = obtenerListaUtensilios();

        for (String utensilio : necesarios) {
            if (!utensiliosDisponibles.contains(utensilio.toLowerCase().trim())) {
                return false;
            }
        }

        return true;
    }

    /**
     * Convierte el string de ingredientes en una lista para facilitar su manejo
     */
    public List<String> obtenerListaIngredientes() {
        if (this.ingredientes == null || this.ingredientes.isEmpty()) {
            return Arrays.asList();
        }
        return Arrays.stream(this.ingredientes.toLowerCase().split(","))
                .map(String::trim)
                .collect(Collectors.toList());
    }

    /**
     * Convierte el string de utensilios en una lista
     */
    public List<String> obtenerListaUtensilios() {
        if (this.utensiliosNecesarios == null || this.utensiliosNecesarios.isEmpty()) {
            return Arrays.asList();
        }
        return Arrays.stream(this.utensiliosNecesarios.toLowerCase().split(","))
                .map(String::trim)
                .collect(Collectors.toList());
    }

    /**
     * Determina si esta es una receta rápida (menos de 5 minutos)
     */
    public boolean esMuyRapida() {
        return this.tiempo < 5;
    }

    /**
     * Determina si esta es una receta rápida (entre 5 y 10 minutos)
     */
    public boolean esRapida() {
        return this.tiempo >= 5 && this.tiempo < 10;
    }

    /**
     * Determina si tiene tiempo de preparación medio (entre 10 y 15 minutos)
     */
    public boolean esTiempoMedio() {
        return this.tiempo >= 10 && this.tiempo < 15;
    }

    /**
     * Determina si tiene tiempo normal (entre 15 y 20 minutos)
     */
    public boolean esTiempoNormal() {
        return this.tiempo >= 15 && this.tiempo <= 20;
    }

    /**
     * Determina si es una receta que toma mucho tiempo (más de 20 minutos)
     */
    public boolean esLarga() {
        return this.tiempo > 20;
    }

    /**
     * Obtiene la categoría de tiempo como string descriptivo
     */
    public String obtenerCategoriaTiempo() {
        if (esMuyRapida()) return "Muy Rápido";
        if (esRapida()) return "Rápido";
        if (esTiempoMedio()) return "Medio";
        if (esTiempoNormal()) return "Normal";
        return "Largo";
    }

    /**
     * Marca esta receta como favorita
     */
    public void marcarComoFavorita() {
        this.favorita = true;
    }

    /**
     * Desmarca esta receta de favoritos
     */
    public void desmarcarFavorita() {
        this.favorita = false;
    }

    /**
     * Alterna el estado de favorito
     */
    public void alternarFavorita() {
        this.favorita = !this.favorita;
    }

    /**
     * Verifica si la receta requiere un ingrediente específico
     */
    public boolean requiereIngrediente(String ingrediente) {
        if (this.ingredientes == null || ingrediente == null) {
            return false;
        }
        return this.ingredientes.toLowerCase().contains(ingrediente.toLowerCase());
    }

    /**
     * Verifica si la receta requiere un utensilio específico
     */
    public boolean requiereUtensilio(String utensilio) {
        if (this.utensiliosNecesarios == null || utensilio == null) {
            return false;
        }
        return this.utensiliosNecesarios.toLowerCase().contains(utensilio.toLowerCase());
    }

    /**
     * Obtiene un resumen de la receta para mostrar en listados
     */
    public String obtenerResumen() {
        return String.format("%s (%d min) - %s",
                this.nombre,
                this.tiempo,
                this.favorita ? "⭐ Favorita" : "");
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            this.nombre = nombre;
        }
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getUtensiliosNecesarios() {
        return utensiliosNecesarios;
    }

    public void setUtensiliosNecesarios(String utensiliosNecesarios) {
        this.utensiliosNecesarios = utensiliosNecesarios;
    }

    public String getPasos() {
        return pasos;
    }

    public void setPasos(String pasos) {
        this.pasos = pasos;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        if (tiempo >= 0) {  // Validación: el tiempo no puede ser negativo
            this.tiempo = tiempo;
        }
    }

    public boolean isFavorita() {
        return favorita;
    }

    public void setFavorita(boolean favorita) {
        this.favorita = favorita;
    }

    public String getInformacionNutricional() {
        return informacionNutricional;
    }

    public void setInformacionNutricional(String informacionNutricional) {
        this.informacionNutricional = informacionNutricional;
    }

    /**
     * Verifica si la receta tiene información nutricional
     */
    public boolean tieneInfoNutricional() {
        return informacionNutricional != null && !informacionNutricional.isEmpty();
    }
    // ============ MÉTODOS HEREDADOS DE OBJECT ============

    @Override
    public String toString() {
        return "Receta{" +
                "nombre='" + nombre + '\'' +
                ", tiempo=" + tiempo +
                ", favorita=" + favorita +
                '}';
    }
}
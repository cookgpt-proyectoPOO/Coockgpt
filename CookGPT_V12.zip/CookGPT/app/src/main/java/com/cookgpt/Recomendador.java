
package com.cookgpt;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Recomendador: Sugiere Top-N recetas "Recomendadas para ti"
 * en base al historial (últimos ~50 vistos) usando una bolsa de palabras simple.
 */
public class Recomendador {

    private final AppDatabase db;
    private static final int MAX_HIST = 50;

    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
            "de","la","el","los","las","y","o","u","en","con","para","por","del","al",
            "a","un","una","unos","unas","que","se","es","son","su","sus","mi","mis",
            "tu","tus","su","sus","como","mas","más","menos","si","no"
    ));
    private static final Pattern SPLIT = Pattern.compile("[^a-záéíóúüñ]+");

    public Recomendador(AppDatabase db){
        this.db = db;
    }

    /** Devuelve Top N recomendaciones para username */
    public List<Receta> recomendarTopN(String username, int N){
        // 1) historial reciente
        List<HistorialReceta> historial = db.historialRecetaDao().obtenerPorUsuario(username);
        if (historial == null) historial = new ArrayList<>();
        // ordenar desc por fecha y limitar
        historial.sort(Comparator.comparingLong(HistorialReceta::getFechaVista).reversed());
        if (historial.size() > MAX_HIST) historial = historial.subList(0, MAX_HIST);

        // construir set de vistas
        Set<String> vistas = historial.stream()
                .map(HistorialReceta::getNombreReceta)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        // 2) perfil (bolsa de palabras) de lo visto
        Map<String,Integer> perfil = new HashMap<>();
        for (HistorialReceta h : historial){
            Receta r = db.recetaDao().getByNombre(h.getNombreReceta());
            if (r != null){
                for (String w : tokensDeReceta(r)){
                    if (STOP.contains(w) || w.isEmpty()) continue;
                    perfil.put(w, perfil.getOrDefault(w,0)+1);
                }
            }
        }

        // 3) si no hay perfil → fallback aleatorio
        List<Receta> catalogo = db.recetaDao().getAll();
        if (perfil.isEmpty()){
            // quitar vistas
            List<Receta> candidatos = catalogo.stream()
                .filter(rc -> !vistas.contains(rc.getNombre()))
                .collect(Collectors.toList());
            Collections.shuffle(candidatos);
            if (candidatos.size() > N) return candidatos.subList(0,N);
            return candidatos;
        }

        // 4) puntuar cada receta
        List<Scored> scored = new ArrayList<>();
        for (Receta r : catalogo){
            if (vistas.contains(r.getNombre())) continue; // evitar repetidas
            int s = 0;
            for (String w : tokensDeReceta(r)){
                if (STOP.contains(w) || w.isEmpty()) continue;
                s += perfil.getOrDefault(w, 0);
            }
            scored.add(new Scored(r, s));
        }

        // 5) ordenar por puntaje desc y devolver Top N
        scored.sort((a,b) -> Integer.compare(b.score, a.score));
        List<Receta> res = new ArrayList<>();
        for (int i=0; i<scored.size() && res.size()<N; i++){
            res.add(scored.get(i).r);
        }
        return res;
    }

    private static class Scored{
        Receta r; int score;
        Scored(Receta r, int score){ this.r=r; this.score=score; }
    }

    /** Extrae tokens de nombre, ingredientes, pasos e info nutricional */
    private List<String> tokensDeReceta(Receta r){
        StringBuilder sb = new StringBuilder();
        if (r.getNombre()!=null) sb.append(' ').append(r.getNombre());
        if (r.getIngredientes()!=null) sb.append(' ').append(r.getIngredientes());
        if (r.getPasos()!=null) sb.append(' ').append(r.getPasos());
        try {
            // todo puede no existir en todas las recetas; por eso try/catch
            if (r.getInformacionNutricional()!=null) sb.append(' ').append(r.getInformacionNutricional());
        } catch (Throwable t){ /* ignorar */ }

        String lower = sb.toString().toLowerCase(Locale.ROOT);
        String[] parts = SPLIT.split(lower);
        return Arrays.asList(parts);
    }
}

package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import androidx.room.Room;
import android.content.Intent;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    AppDatabase db;
    EditText input;
    Button btnGuardar, btnUtensilios, btnSugerencias;
    TextView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.inputIngrediente);
        btnGuardar = findViewById(R.id.btnGuardar);
        lista = findViewById(R.id.txtLista);
        btnUtensilios = findViewById(R.id.btnUtensilios);
        btnSugerencias = findViewById(R.id.btnSugerencias);

        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        inicializarDatos();

        btnGuardar.setOnClickListener(v -> {
            String nombre = input.getText().toString().trim();
            if (!nombre.isEmpty()) {
                Ingrediente ing = new Ingrediente();
                ing.nombre = nombre;
                ing.disponible = true;
                db.ingredienteDao().insertar(ing);
                mostrarIngredientes();
                input.setText("");
                Toast.makeText(this, "Ingrediente guardado: " + nombre, Toast.LENGTH_SHORT).show();
            }
        });

        btnUtensilios.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, UtensiliosActivity.class);
            startActivity(i);
        });

        btnSugerencias.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, SugerenciasActivity.class);
            startActivity(i);
        });

        mostrarIngredientes();
    }

    private void inicializarDatos() {
        List<Receta> recetasExistentes = db.recetaDao().getAll();
        if (recetasExistentes.isEmpty()) {
            agregarRecetasDeEjemplo();
        }

        List<Utensilio> utensiliosExistentes = db.utensilioDao().getAll();
        if (utensiliosExistentes.isEmpty()) {
            agregarUtensiliosBasicos();
        }
    }

    private void agregarRecetasDeEjemplo() {
        // ========== DESAYUNOS ==========

        Receta r1 = new Receta();
        r1.nombre = "Huevos revueltos con pan";
        r1.ingredientes = "huevos,sal,aceite,pan";
        r1.utensiliosNecesarios = "sartén,tenedor";
        r1.pasos = "\n1. Batir los huevos con sal (1 min)\n2. Calentar aceite en sartén (1 min)\n3. Verter huevos y revolver (1 min)\n4. Tostar el pan (1 min)\n5. Servir los huevos sobre el pan (2 min)";
        r1.tiempo = 7;
        db.recetaDao().insertar(r1);

        Receta r2 = new Receta();
        r2.nombre = "Avena con fruta";
        r2.ingredientes = "avena,agua,leche,fruta";
        r2.utensiliosNecesarios = "cazo,cuchara";
        r2.pasos = "\n1. Poner avena y agua/leche a calentar (2 min)\n2. Cocer hasta que espese (2 min)\n3. Agregar fruta picada (2 min)\n4. Servir en tazón (2 min)";
        r2.tiempo = 10;
        db.recetaDao().insertar(r2);

        Receta r3 = new Receta();
        r3.nombre = "Tostadas con aguacate";
        r3.ingredientes = "pan,aguacate,sal,limon";
        r3.utensiliosNecesarios = "cuchillo,tenedor";
        r3.pasos = "\n1. Tostar el pan (1 min)\n2. Machacar el aguacate con sal y limón (1 min)\n3. Untar aguacate sobre el pan (1 min)\n4. Servir (3 min)";
        r3.tiempo = 7;
        db.recetaDao().insertar(r3);

        Receta r4 = new Receta();
        r4.nombre = "Sándwich de jamón y queso";
        r4.ingredientes = "pan,jamon,queso";
        r4.utensiliosNecesarios = "sartén,espátula";
        r4.pasos = "\n1. Colocar jamón y queso entre los panes (2 min)\n2. Tostar hasta que se derrita el queso (2 min)\n3. Servir (2 min)";
        r4.tiempo = 8;
        db.recetaDao().insertar(r4);

        Receta r5 = new Receta();
        r5.nombre = "Hot cakes rápidos";
        r5.ingredientes = "huevo,harina,leche,azucar";
        r5.utensiliosNecesarios = "sartén,cuchara";
        r5.pasos = "\n1. Mezclar ingredientes hasta formar masa (2 min)\n2. Calentar sartén (2 min)\n3. Verter masa y cocinar por ambos lados (2 min)\n4. Servir con miel o mermelada (5 min)";
        r5.tiempo = 12;
        db.recetaDao().insertar(r5);

        Receta r6 = new Receta();
        r6.nombre = "Yogur con granola y miel";
        r6.ingredientes = "yogur,granola,miel";
        r6.utensiliosNecesarios = "tazón,cuchara";
        r6.pasos = "\n1. Verter yogur en tazón (1 min)\n2. Agregar granola (1 min)\n3. Añadir miel encima (2 min)";
        r6.tiempo = 5;
        db.recetaDao().insertar(r6);

        Receta r7 = new Receta();
        r7.nombre = "Huevos duros";
        r7.ingredientes = "huevos,agua,sal";
        r7.utensiliosNecesarios = "cazo,cuchara";
        r7.pasos = "\n1. Colocar huevos en cazo con agua (3 min)\n2. Hervir 8 minutos (3 min)\n3. Enfriar y pelar (3 min)";
        r7.tiempo = 10;
        db.recetaDao().insertar(r7);

        Receta r8 = new Receta();
        r8.nombre = "Pan con crema de maní y plátano";
        r8.ingredientes = "pan,crema de mani,platano";
        r8.utensiliosNecesarios = "cuchillo";
        r8.pasos = "\n1. Untar crema en pan (1 min)\n2. Cortar plátano en rodajas (1 min)\n3. Colocar sobre el pan (3 min)";
        r8.tiempo = 6;
        db.recetaDao().insertar(r8);

        Receta r9 = new Receta();
        r9.nombre = "Batido energético";
        r9.ingredientes = "platano,leche,avena,miel";
        r9.utensiliosNecesarios = "licuadora";
        r9.pasos = "\n1. Colocar ingredientes en licuadora (2 min)\n2. Licuar hasta homogeneizar (2 min)\n3. Servir (2 min)";
        r9.tiempo = 7;
        db.recetaDao().insertar(r9);

        Receta r10 = new Receta();
        r10.nombre = "Quesadilla de queso";
        r10.ingredientes = "tortilla,queso";
        r10.utensiliosNecesarios = "sartén,espátula";
        r10.pasos = "\n1. Calentar sartén (1 min)\n2. Colocar tortilla con queso (1 min)\n3. Doblar y dorar ambos lados (1 min)\n4. Servir (2 min)";
        r10.tiempo = 6;
        db.recetaDao().insertar(r10);

        // ========== ALMUERZOS ==========

        Receta r11 = new Receta();
        r11.nombre = "Arroz con huevo";
        r11.ingredientes = "arroz,huevo,aceite,sal";
        r11.utensiliosNecesarios = "olla,sartén";
        r11.pasos = "\n1. Cocer arroz (4 min)\n2. Freír huevo (4 min)\n3. Servir arroz con huevo encima (5 min)";
        r11.tiempo = 15;
        db.recetaDao().insertar(r11);

        Receta r12 = new Receta();
        r12.nombre = "Pasta con salsa de tomate";
        r12.ingredientes = "pasta,salsa de tomate,sal";
        r12.utensiliosNecesarios = "olla,cuchara";
        r12.pasos = "\n1. Cocer pasta (5 min)\n2. Calentar salsa (5 min)\n3. Mezclar y servir (6 min)";
        r12.tiempo = 18;
        db.recetaDao().insertar(r12);

        Receta r13 = new Receta();
        r13.nombre = "Tacos de atún";
        r13.ingredientes = "atun,tortilla,limon,mayonesa";
        r13.utensiliosNecesarios = "cuchara";
        r13.pasos = "\n1. Mezclar atún con limón y mayonesa (2 min)\n2. Colocar en tortillas (2 min)\n3. Servir (3 min)";
        r13.tiempo = 8;
        db.recetaDao().insertar(r13);

        Receta r14 = new Receta();
        r14.nombre = "Arroz frito con verduras";
        r14.ingredientes = "arroz,verduras,salsa soya";
        r14.utensiliosNecesarios = "sartén,cuchara";
        r14.pasos = "\n1. Saltear verduras (2 min)\n2. Agregar arroz (2 min)\n3. Añadir salsa soya (2 min)\n4. Servir (5 min)";
        r14.tiempo = 12;
        db.recetaDao().insertar(r14);

        Receta r15 = new Receta();
        r15.nombre = "Pollo al sartén";
        r15.ingredientes = "pechuga de pollo,sal,aceite,limon";
        r15.utensiliosNecesarios = "sartén,pinzas";
        r15.pasos = "\n1. Sazonar pollo (5 min)\n2. Cocinar por ambos lados (5 min)\n3. Servir con limón (7 min)";
        r15.tiempo = 20;
        db.recetaDao().insertar(r15);

        Receta r16 = new Receta();
        r16.nombre = "Ensalada de atún";
        r16.ingredientes = "atun,lechuga,tomate,limon";
        r16.utensiliosNecesarios = "tazón,tenedor";
        r16.pasos = "\n1. Picar verduras (2 min)\n2. Agregar atún (2 min)\n3. Mezclar con limón (4 min)";
        r16.tiempo = 9;
        db.recetaDao().insertar(r16);

        Receta r17 = new Receta();
        r17.nombre = "Huevos con frijoles";
        r17.ingredientes = "huevos,frijoles,aceite";
        r17.utensiliosNecesarios = "sartén";
        r17.pasos = "\n1. Freír huevos (3 min)\n2. Calentar frijoles (3 min)\n3. Servir juntos (3 min)";
        r17.tiempo = 10;
        db.recetaDao().insertar(r17);

        Receta r18 = new Receta();
        r18.nombre = "Sándwich de pollo";
        r18.ingredientes = "pan,pollo,mayonesa";
        r18.utensiliosNecesarios = "cuchillo";
        r18.pasos = "\n1. Mezclar pollo con mayonesa (2 min)\n2. Colocar entre panes (2 min)\n3. Servir (3 min)";
        r18.tiempo = 8;
        db.recetaDao().insertar(r18);

        Receta r19 = new Receta();
        r19.nombre = "Papas fritas con huevo";
        r19.ingredientes = "papas,huevo,aceite,sal";
        r19.utensiliosNecesarios = "sartén,cuchillo";
        r19.pasos = "\n1. Cortar papas (3 min)\n2. Freír hasta dorar (3 min)\n3. Agregar huevo y cocinar (3 min)\n4. Servir (4 min)";
        r19.tiempo = 15;
        db.recetaDao().insertar(r19);

        Receta r20 = new Receta();
        r20.nombre = "Wrap de jamón";
        r20.ingredientes = "tortilla,jamon,lechuga,mayonesa";
        r20.utensiliosNecesarios = "cuchillo";
        r20.pasos = "\n1. Untar mayonesa (1 min)\n2. Colocar ingredientes (1 min)\n3. Enrollar tortilla (1 min)\n4. Servir (4 min)";
        r20.tiempo = 8;
        db.recetaDao().insertar(r20);

        // ========== CENAS ==========

        Receta r21 = new Receta();
        r21.nombre = "Sopa instantánea con huevo";
        r21.ingredientes = "sopa instantanea,huevo";
        r21.utensiliosNecesarios = "olla,cuchara";
        r21.pasos = "\n1. Hervir agua (1 min)\n2. Agregar sopa (1 min)\n3. Romper huevo y cocer (1 min)\n4. Servir (3 min)";
        r21.tiempo = 8;
        db.recetaDao().insertar(r21);

        Receta r22 = new Receta();
        r22.nombre = "Arroz con verduras";
        r22.ingredientes = "arroz,verduras";
        r22.utensiliosNecesarios = "olla,cuchara";
        r22.pasos = "\n1. Cocer arroz (4 min)\n2. Agregar verduras (4 min)\n3. Sazonar al gusto (5 min)";
        r22.tiempo = 15;
        db.recetaDao().insertar(r22);

        Receta r23 = new Receta();
        r23.nombre = "Tostadas con frijoles";
        r23.ingredientes = "tostadas,frijoles,queso";
        r23.utensiliosNecesarios = "cuchillo";
        r23.pasos = "\n1. Untar frijoles (2 min)\n2. Agregar queso (2 min)\n3. Servir (4 min)";
        r23.tiempo = 9;
        db.recetaDao().insertar(r23);

        Receta r24 = new Receta();
        r24.nombre = "Quesadilla de jamón";
        r24.ingredientes = "tortilla,jamon,queso";
        r24.utensiliosNecesarios = "sartén,espátula";
        r24.pasos = "\n1. Colocar ingredientes (2 min)\n2. Doblar tortilla (2 min)\n3. Calentar hasta derretir (3 min)";
        r24.tiempo = 8;
        db.recetaDao().insertar(r24);

        Receta r25 = new Receta();
        r25.nombre = "Puré de papa con atún";
        r25.ingredientes = "papas,atun,sal,mantequilla";
        r25.utensiliosNecesarios = "olla,tenedor";
        r25.pasos = "\n1. Cocer papas (4 min)\n2. Machacar con mantequilla (4 min)\n3. Agregar atún (5 min)";
        r25.tiempo = 15;
        db.recetaDao().insertar(r25);

        Receta r26 = new Receta();
        r26.nombre = "Huevos a la mexicana";
        r26.ingredientes = "huevos,tomate,cebolla,chile";
        r26.utensiliosNecesarios = "sartén,cuchillo";
        r26.pasos = "\n1. Picar verduras (3 min)\n2. Sofreír (3 min)\n3. Agregar huevos y cocinar (3 min)";
        r26.tiempo = 10;
        db.recetaDao().insertar(r26);

        Receta r27 = new Receta();
        r27.nombre = "Pasta con mantequilla";
        r27.ingredientes = "pasta,mantequilla,sal";
        r27.utensiliosNecesarios = "olla,sartén";
        r27.pasos = "\n1. Cocer pasta (3 min)\n2. Agregar mantequilla derretida (3 min)\n3. Servir (5 min)";
        r27.tiempo = 12;
        db.recetaDao().insertar(r27);

        Receta r28 = new Receta();
        r28.nombre = "Sopa de verduras";
        r28.ingredientes = "verduras,agua,sal";
        r28.utensiliosNecesarios = "olla,cuchara";
        r28.pasos = "\n1. Hervir agua (5 min)\n2. Agregar verduras (5 min)\n3. Cocer hasta tiernas (7 min)";
        r28.tiempo = 20;
        db.recetaDao().insertar(r28);

        Receta r29 = new Receta();
        r29.nombre = "Tortilla francesa";
        r29.ingredientes = "huevos,sal,aceite";
        r29.utensiliosNecesarios = "sartén,tenedor";
        r29.pasos = "\n1. Batir huevos (2 min)\n2. Verter y enrollar en sartén (2 min)\n3. Servir (4 min)";
        r29.tiempo = 9;
        db.recetaDao().insertar(r29);

        Receta r30 = new Receta();
        r30.nombre = "Pan con queso fundido";
        r30.ingredientes = "pan,queso,mantequilla";
        r30.utensiliosNecesarios = "sartén,espátula";
        r30.pasos = "\n1. Untar mantequilla (2 min)\n2. Agregar queso (2 min)\n3. Tostar hasta fundir (3 min)";
        r30.tiempo = 8;
        db.recetaDao().insertar(r30);

        // ========== SNACKS ==========

        Receta r31 = new Receta();
        r31.nombre = "Palomitas de microondas";
        r31.ingredientes = "palomitas";
        r31.utensiliosNecesarios = "microondas,tazón";
        r31.pasos = "\n1. Colocar bolsa en microondas (1 min)\n2. Cocinar según instrucciones (1 min)\n3. Servir (2 min)";
        r31.tiempo = 5;
        db.recetaDao().insertar(r31);

        Receta r32 = new Receta();
        r32.nombre = "Sandía con limón";
        r32.ingredientes = "sandia,limon";
        r32.utensiliosNecesarios = "cuchillo";
        r32.pasos = "\n1. Cortar sandía (1 min)\n2. Agregar limón (1 min)\n3. Servir (0 min)";
        r32.tiempo = 3;
        db.recetaDao().insertar(r32);

        Receta r33 = new Receta();
        r33.nombre = "Galletas con yogur";
        r33.ingredientes = "galletas,yogur";
        r33.utensiliosNecesarios = "cuchara";
        r33.pasos = "\n1. Colocar galletas (1 min)\n2. Servir yogur encima (2 min)";
        r33.tiempo = 4;
        db.recetaDao().insertar(r33);

        Receta r34 = new Receta();
        r34.nombre = "Pan con mermelada";
        r34.ingredientes = "pan,mermelada";
        r34.utensiliosNecesarios = "cuchillo";
        r34.pasos = "\n1. Tostar pan (1 min)\n2. Untar mermelada (1 min)\n3. Servir (1 min)";
        r34.tiempo = 4;
        db.recetaDao().insertar(r34);

        Receta r35 = new Receta();
        r35.nombre = "Fruta picada";
        r35.ingredientes = "manzana,platano,melon";
        r35.utensiliosNecesarios = "cuchillo,tazón";
        r35.pasos = "\n1. Pelar frutas (1 min)\n2. Cortar en trozos (1 min)\n3. Servir (3 min)";
        r35.tiempo = 6;
        db.recetaDao().insertar(r35);

        Receta r36 = new Receta();
        r36.nombre = "Cereal con leche";
        r36.ingredientes = "cereal,leche";
        r36.utensiliosNecesarios = "tazón,cuchara";
        r36.pasos = "\n1. Verter cereal (1 min)\n2. Agregar leche (1 min)";
        r36.tiempo = 3;
        db.recetaDao().insertar(r36);

        Receta r37 = new Receta();
        r37.nombre = "Nachos con queso";
        r37.ingredientes = "totopos,queso";
        r37.utensiliosNecesarios = "microondas";
        r37.pasos = "\n1. Colocar totopos (2 min)\n2. Agregar queso (2 min)\n3. Calentar hasta fundir (2 min)";
        r37.tiempo = 7;
        db.recetaDao().insertar(r37);

        Receta r38 = new Receta();
        r38.nombre = "Plátano con miel";
        r38.ingredientes = "platano,miel";
        r38.utensiliosNecesarios = "cuchillo";
        r38.pasos = "\n1. Cortar plátano (1 min)\n2. Agregar miel (1 min)";
        r38.tiempo = 3;
        db.recetaDao().insertar(r38);

        Receta r39 = new Receta();
        r39.nombre = "Tostadas de crema y azúcar";
        r39.ingredientes = "pan,mantequilla,azucar";
        r39.utensiliosNecesarios = "sartén,cuchillo";
        r39.pasos = "\n1. Untar mantequilla (1 min)\n2. Espolvorear azúcar (1 min)\n3. Tostar (3 min)";
        r39.tiempo = 6;
        db.recetaDao().insertar(r39);

        Receta r40 = new Receta();
        r40.nombre = "Gelatina lista";
        r40.ingredientes = "gelatina";
        r40.utensiliosNecesarios = "cuchara,tazón";
        r40.pasos = "\n1. Servir en tazón (1 min)\n2. Comer (0 min)";
        r40.tiempo = 2;
        db.recetaDao().insertar(r40);
    }

    private void agregarUtensiliosBasicos() {
        String[] nombresUtensilios = {"Sartén", "Olla", "Microondas", "Batidora", "Cuchillo",
                "Tabla de cortar", "Tenedor", "Cuchara", "Cazo", "Espátula",
                "Tazón", "Licuadora", "Pinzas"};

        for (String nombre : nombresUtensilios) {
            Utensilio u = new Utensilio();
            u.nombre = nombre;
            u.disponible = false;
            db.utensilioDao().insertar(u);
        }
    }

    private void mostrarIngredientes() {
        List<Ingrediente> ingredientes = db.ingredienteDao().getAll();
        StringBuilder sb = new StringBuilder("Ingredientes disponibles:\n");
        if (ingredientes.isEmpty()) {
            sb.append("No hay ingredientes registrados");
        } else {
            for (Ingrediente i : ingredientes) {
                if (i.disponible) {
                    sb.append("✓ ").append(i.nombre).append("\n");
                }
            }
        }
        lista.setText(sb.toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        mostrarIngredientes();
    }
}
package com.cookgpt;

import java.util.List;

public class GestorUsuario {

    private UsuarioDao usuarioDao;

    public GestorUsuario(UsuarioDao usuarioDao) {
        this.usuarioDao = usuarioDao;
    }

    public String registrarUsuario(String username, String password, String email) {
        if (!Usuario.usernameValido(username)) {
            return "Error: El username debe tener entre 3 y 20 caracteres (solo letras, números y guion bajo)";
        }

        if (!Usuario.passwordValida(password)) {
            return "Error: La contraseña debe tener al menos 4 caracteres";
        }

        if (!Usuario.emailValido(email)) {
            return "Error: El email no es válido";
        }

        Usuario existente = usuarioDao.buscarPorUsername(username);
        if (existente != null) {
            return "Error: Este username ya está registrado";
        }

        Usuario emailExistente = usuarioDao.buscarPorEmail(email);
        if (emailExistente != null) {
            return "Error: Este email ya está registrado";
        }


        Usuario nuevoUsuario = new Usuario(username, password, email);

        if (usuarioDao.contarUsuarios() == 0) {
            nuevoUsuario.hacerAdministrador();
        }

        usuarioDao.insertar(nuevoUsuario);

        String rol = nuevoUsuario.esAdmin() ? " (Administrador)" : "";
        return "¡Usuario registrado exitosamente!" + rol;
    }

    public Usuario iniciarSesion(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            return null;
        }

        if (password == null || password.trim().isEmpty()) {
            return null;
        }

        Usuario usuario = usuarioDao.login(username.trim(), password);
        return usuario;
    }

    public boolean credencialesValidas(String username, String password) {
        return iniciarSesion(username, password) != null;
    }

    public List<Usuario> obtenerTodos() {
        return usuarioDao.getAll();
    }

    public List<Usuario> obtenerAdministradores() {
        return usuarioDao.getAdministradores();
    }

    public List<Usuario> obtenerUsuariosNormales() {
        return usuarioDao.getUsuariosNormales();
    }

    public Usuario buscarPorUsername(String username) {
        return usuarioDao.buscarPorUsername(username);
    }

    public Usuario buscarPorEmail(String email) {
        return usuarioDao.buscarPorEmail(email);
    }

    public boolean hayUsuariosRegistrados() {
        return usuarioDao.contarUsuarios() > 0;
    }

    public int contarUsuarios() {
        return usuarioDao.contarUsuarios();
    }

    public String eliminarUsuario(Usuario usuarioAEliminar, Usuario usuarioActual) {
        if (!usuarioActual.esAdmin()) {
            return "Error: Solo los administradores pueden eliminar usuarios";
        }

        if (usuarioAEliminar.getId() == usuarioActual.getId()) {
            return "Error: No puedes eliminar tu propia cuenta mientras estás conectado";
        }

        if (usuarioAEliminar.esAdmin()) {
            List<Usuario> admins = usuarioDao.getAdministradores();
            if (admins.size() <= 1) {
                return "Error: No se puede eliminar al último administrador del sistema";
            }
        }

        return "Usuario eliminado exitosamente";
    }

    public String hacerAdministrador(Usuario usuario, Usuario usuarioActual) {
        if (!usuarioActual.esAdmin()) {
            return "Error: Solo los administradores pueden asignar privilegios";
        }

        if (usuario.esAdmin()) {
            return "Este usuario ya es administrador";
        }

        usuario.hacerAdministrador();
        usuarioDao.actualizar(usuario);
        return "Usuario promovido a administrador exitosamente";
    }

    public String quitarAdministrador(Usuario usuario, Usuario usuarioActual) {
        if (!usuarioActual.esAdmin()) {
            return "Error: Solo los administradores pueden quitar privilegios";
        }

        if (usuario.getId() == usuarioActual.getId()) {
            return "Error: No puedes quitarte tus propios privilegios";
        }

        if (!usuario.esAdmin()) {
            return "Este usuario no es administrador";
        }

        // Verificar que no sea el único admin
        List<Usuario> admins = usuarioDao.getAdministradores();
        if (admins.size() <= 1) {
            return "Error: No se puede quitar privilegios al único administrador";
        }

        usuario.quitarAdministrador();
        usuarioDao.actualizar(usuario);
        return "Privilegios de administrador removidos exitosamente";
    }

    public String cambiarPassword(Usuario usuario, String passwordActual, String nuevaPassword) {
        // Verificar password actual
        if (!usuario.verificarPassword(passwordActual)) {
            return "Error: La contraseña actual es incorrecta";
        }

        // Validar nueva password
        if (!Usuario.passwordValida(nuevaPassword)) {
            return "Error: La nueva contraseña debe tener al menos 4 caracteres";
        }

        usuario.cambiarPassword(nuevaPassword);
        usuarioDao.actualizar(usuario);
        return "Contraseña cambiada exitosamente";
    }

    public String generarListaUsuarios() {
        List<Usuario> usuarios = obtenerTodos();
        StringBuilder sb = new StringBuilder();

        if (usuarios.isEmpty()) {
            sb.append("No hay usuarios registrados");
        } else {
            for (Usuario u : usuarios) {
                String rol = u.esAdmin() ? " [ADMIN]" : " [Usuario]";
                sb.append("• ").append(u.getUsername()).append(rol).append("\n");
            }
        }

        return sb.toString();
    }

    /**
     * Obtiene estadísticas del sistema
     */
    public String obtenerEstadisticas() {
        int totalUsuarios = contarUsuarios();
        int admins = obtenerAdministradores().size();
        int usuariosNormales = obtenerUsuariosNormales().size();

        return String.format(
                "Estadísticas del Sistema\n\n" +
                        "Total de usuarios: %d\n" +
                        "Administradores: %d\n" +
                        "Usuarios normales: %d",
                totalUsuarios, admins, usuariosNormales
        );
    }
}
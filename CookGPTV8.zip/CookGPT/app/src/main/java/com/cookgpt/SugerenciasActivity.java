package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.content.Intent;
import androidx.room.Room;
import java.util.List;

/**
 * SugerenciasActivity: Pantalla que muestra sugerencias de recetas basadas en
 * ingredientes y utensilios disponibles.
 *
 * REFACTORIZACIÓN APLICADA:
 * - ANTES: Esta Activity tenía métodos como puedeHacerReceta() y cumpleFiltroTiempo()
 * - AHORA: Esa lógica está en la clase Receta y en GestorRecetas
 *          Esta clase solo maneja la interfaz de usuario
 */
public class SugerenciasActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private LinearLayout layoutRecetas;
    private Button btnVolver;
    private RadioGroup radioGroupTiempo;
    private RadioButton radioTodos, radioMuyRapido, radioRapido, radioMedio, radioNormal, radioLargo;

    // ===== GESTORES =====
    private GestorRecetas gestorRecetas;
    private GestorIngredientes gestorIngredientes;
    private GestorUtensilios gestorUtensilios;

    // ===== BASE DE DATOS =====
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sugerencias);

        // Inicializar todo
        inicializarBaseDatos();
        inicializarGestores();
        conectarElementosUI();
        configurarListeners();

        // Mostrar todas las recetas por defecto
        radioTodos.setChecked(true);
        mostrarRecetasPosibles();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestores() {
        gestorRecetas = new GestorRecetas(db.recetaDao());
        gestorIngredientes = new GestorIngredientes(db.ingredienteDao());
        gestorUtensilios = new GestorUtensilios(db.utensilioDao());
    }

    private void conectarElementosUI() {
        layoutRecetas = findViewById(R.id.layoutRecetas);
        btnVolver = findViewById(R.id.btnVolverIngredientes);
        radioGroupTiempo = findViewById(R.id.radioGroupTiempo);
        radioTodos = findViewById(R.id.radioTodos);
        radioMuyRapido = findViewById(R.id.radioMuyRapido);
        radioRapido = findViewById(R.id.radioRapido);
        radioMedio = findViewById(R.id.radioMedio);
        radioNormal = findViewById(R.id.radioNormal);
        radioLargo = findViewById(R.id.radioLargo);
    }

    private void configurarListeners() {
        // Listener para cambios en el filtro de tiempo
        radioGroupTiempo.setOnCheckedChangeListener((group, checkedId) -> {
            layoutRecetas.removeAllViews();
            mostrarRecetasPosibles();
        });

        // Botón volver
        btnVolver.setOnClickListener(v -> {
            Intent i = new Intent(SugerenciasActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }

    /**
     * Muestra las recetas que se pueden preparar con los ingredientes y utensilios disponibles
     * ANTES: Toda esta lógica estaba mezclada aquí
     * AHORA: Usamos los gestores para obtener la información
     */
    private void mostrarRecetasPosibles() {
        // Obtener ingredientes y utensilios disponibles usando los gestores
        List<Ingrediente> ingredientesDisponibles = gestorIngredientes.obtenerDisponibles();
        List<Utensilio> utensiliosDisponibles = gestorUtensilios.obtenerDisponibles();

        // Obtener recetas que se pueden hacer (el gestor maneja la lógica)
        List<Receta> recetasPosibles = gestorRecetas.obtenerRecetasPosibles(
                ingredientesDisponibles,
                utensiliosDisponibles
        );

        // Filtrar por tiempo si es necesario
        GestorRecetas.CategoríaTiempo categoríaTiempo = obtenerCategoríaTiempoSeleccionada();
        List<Receta> recetasFiltradas = gestorRecetas.filtrarPorTiempo(
                recetasPosibles,
                categoríaTiempo
        );

        // Mostrar las recetas en pantalla
        if (recetasFiltradas.isEmpty()) {
            mostrarMensajeNoHayRecetas();
        } else {
            for (Receta receta : recetasFiltradas) {
                agregarRecetaAlLayout(receta);
            }
        }
    }

    /**
     * Obtiene la categoría de tiempo seleccionada en los radio buttons
     */
    private GestorRecetas.CategoríaTiempo obtenerCategoríaTiempoSeleccionada() {
        int filtroSeleccionado = radioGroupTiempo.getCheckedRadioButtonId();

        if (filtroSeleccionado == R.id.radioTodos) {
            return GestorRecetas.CategoríaTiempo.TODOS;
        } else if (filtroSeleccionado == R.id.radioMuyRapido) {
            return GestorRecetas.CategoríaTiempo.MUY_RAPIDO;
        } else if (filtroSeleccionado == R.id.radioRapido) {
            return GestorRecetas.CategoríaTiempo.RAPIDO;
        } else if (filtroSeleccionado == R.id.radioMedio) {
            return GestorRecetas.CategoríaTiempo.MEDIO;
        } else if (filtroSeleccionado == R.id.radioNormal) {
            return GestorRecetas.CategoríaTiempo.NORMAL;
        } else if (filtroSeleccionado == R.id.radioLargo) {
            return GestorRecetas.CategoríaTiempo.LARGO;
        }

        return GestorRecetas.CategoríaTiempo.TODOS;
    }

    /**
     * Muestra un mensaje cuando no hay recetas disponibles
     */
    private void mostrarMensajeNoHayRecetas() {
        TextView txtNoRecetas = new TextView(this);
        txtNoRecetas.setText("No hay recetas posibles con los ingredientes, utensilios y tiempo seleccionados.\n\nIntenta cambiar el filtro de tiempo o agregar más ingredientes.");
        txtNoRecetas.setTextSize(16);
        txtNoRecetas.setPadding(20, 20, 20, 20);
        layoutRecetas.addView(txtNoRecetas);
    }

    /**
     * Agrega un botón de receta al layout
     */
    private void agregarRecetaAlLayout(Receta receta) {
        Button btnReceta = new Button(this);

        // Usar el método de la clase Receta para obtener el resumen
        btnReceta.setText(receta.obtenerResumen());
        btnReceta.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        // Click listener para ir al detalle
        btnReceta.setOnClickListener(v -> abrirDetalleReceta(receta));

        layoutRecetas.addView(btnReceta);
    }

    /**
     * Abre la pantalla de detalle de una receta
     */
    private void abrirDetalleReceta(Receta receta) {
        Intent intent = new Intent(SugerenciasActivity.this, DetalleRecetaActivity.class);
        intent.putExtra("nombre", receta.getNombre());
        intent.putExtra("pasos", receta.getPasos());
        intent.putExtra("tiempo", receta.getTiempo());
        intent.putExtra("ingredientes", receta.getIngredientes());
        intent.putExtra("recetaId", receta.getId());
        startActivity(intent);
    }
}

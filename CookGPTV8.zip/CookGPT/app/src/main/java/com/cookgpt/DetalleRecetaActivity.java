package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.room.Room;

/**
 * DetalleRecetaActivity: Pantalla que muestra los detalles de una receta específica.
 *
 * REFACTORIZACIÓN APLICADA:
 * - AHORA usa GestorRecetas para manejar favoritos
 * - Usa getters/setters en lugar de acceso directo
 * - Usa métodos de comportamiento de la clase Receta
 */
public class DetalleRecetaActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private TextView txtNombre, txtPasos, txtTiempo;

    // ===== GESTOR =====
    private GestorRecetas gestorRecetas;

    // ===== BASE DE DATOS =====
    private AppDatabase db;

    // ===== DATOS =====
    private Receta recetaActual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_receta);

        // Inicializar
        inicializarBaseDatos();
        inicializarGestor();
        conectarElementosUI();
        cargarReceta();
        configurarListeners();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestor() {
        gestorRecetas = new GestorRecetas(db.recetaDao());
    }

    private void conectarElementosUI() {
        txtNombre = findViewById(R.id.txtNombre);
        txtPasos = findViewById(R.id.txtPasos);
        txtTiempo = findViewById(R.id.txtTiempo);
    }

    /**
     * Carga la receta desde el Intent y la base de datos
     * ANTES: Accedía directamente a los atributos públicos
     * AHORA: Usa getters y el gestor
     */
    private void cargarReceta() {
        // Obtener datos del Intent
        String nombre = getIntent().getStringExtra("nombre");
        String pasos = getIntent().getStringExtra("pasos");
        int tiempo = getIntent().getIntExtra("tiempo", 0);

        // Intentar cargar la receta completa desde la base de datos
        if (nombre != null) {
            recetaActual = db.recetaDao().getByNombre(nombre);
        }

        if (recetaActual == null) {
            // Fallback: si no se encontró en BD, crear una temporal
            recetaActual = new Receta();
            recetaActual.setNombre(nombre != null ? nombre : "Receta");
            recetaActual.setPasos(pasos != null ? pasos : "");
            recetaActual.setTiempo(tiempo);
            recetaActual.setFavorita(false);
        } else {
            // Priorizar datos de BD si existen
            if (pasos == null) pasos = recetaActual.getPasos();
            if (tiempo == 0) tiempo = recetaActual.getTiempo();
        }

        // Mostrar información usando GETTERS
        txtPasos.setText("Pasos: " + (pasos != null ? pasos : ""));
        txtTiempo.setText("Tiempo: " + tiempo + " min");

        // Renderizar el título con estrella
        renderTitulo();
    }

    /**
     * Configura el listener para marcar/desmarcar favoritos
     */
    private void configurarListeners() {
        txtNombre.setOnClickListener(v -> toggleFavorito());
    }

    /**
     * Alterna el estado de favorito de la receta
     * ANTES: Cambiaba directamente el atributo y llamaba al DAO
     * AHORA: Usa el gestor que encapsula toda esa lógica
     */
    private void toggleFavorito() {
        if (recetaActual.getId() == 0) {
            Toast.makeText(this,
                    "No se pudo guardar favorito (receta sin id).",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // USAR EL GESTOR para manejar favoritos
        gestorRecetas.toggleFavorita(recetaActual);

        // Actualizar la vista
        renderTitulo();

        // Mostrar mensaje usando GETTER
        String mensaje = recetaActual.isFavorita() ?
                "Añadida a favoritos" :
                "Quitada de favoritos";
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }

    /**
     * Renderiza el título con la estrella de favorito
     * ANTES: Accedía directamente a los atributos
     * AHORA: Usa getters
     */
    private void renderTitulo() {
        // USAR GETTERS
        String estrella = (recetaActual != null && recetaActual.isFavorita()) ? " ★" : " ☆";
        String nombreMostrado = (recetaActual != null && recetaActual.getNombre() != null) ?
                recetaActual.getNombre() : "Receta";

        txtNombre.setText("Receta: " + nombreMostrado + estrella);
    }
}

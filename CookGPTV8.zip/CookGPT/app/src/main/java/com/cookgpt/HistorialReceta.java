package com.cookgpt;

public class HistorialReceta {
}

package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import androidx.room.Room;
import android.content.Intent;

/**
 * MainActivity: Pantalla principal de la aplicación CookGPT.
 *
 * REFACTORIZACIÓN APLICADA:
 * - ANTES: Esta clase contenía toda la lógica de negocio mezclada con la UI
 * - AHORA: Esta clase SOLO maneja la interfaz de usuario (UI)
 *          Toda la lógica está en las clases Gestoras
 *
 * PRINCIPIO DE POO:
 * - Separación de Responsabilidades
 * - Esta clase solo se encarga de:
 *   1. Inicializar la interfaz
 *   2. Capturar eventos del usuario (clicks, texto)
 *   3. Llamar a los Gestores para procesar la lógica
 *   4. Mostrar resultados en pantalla
 */
public class MainActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private EditText input;
    private Button btnGuardar, btnUtensilios, btnSugerencias;
    private TextView lista;

    // ===== GESTORES (CLASES CONTROLADORAS) =====
    // Estas clases contienen toda la lógica de negocio
    private GestorIngredientes gestorIngredientes;
    private GestorRecetas gestorRecetas;
    private GestorUtensilios gestorUtensilios;

    // ===== BASE DE DATOS =====
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar la base de datos
        inicializarBaseDatos();

        // Inicializar los gestores (clases controladoras)
        inicializarGestores();

        // Conectar los elementos de la interfaz
        conectarElementosUI();

        // Inicializar datos de ejemplo si es necesario
        inicializarDatos();

        // Configurar los listeners (eventos de click)
        configurarListeners();

        // Mostrar la lista inicial de ingredientes
        mostrarIngredientes();
    }

    /**
     * Inicializa la base de datos Room
     */
    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    /**
     * Inicializa los gestores pasándoles los DAOs necesarios
     * ESTO ES CLAVE: Los gestores separan la lógica de la interfaz
     */
    private void inicializarGestores() {
        gestorIngredientes = new GestorIngredientes(db.ingredienteDao());
        gestorRecetas = new GestorRecetas(db.recetaDao());
        gestorUtensilios = new GestorUtensilios(db.utensilioDao());
    }

    /**
     * Conecta las variables con los elementos de la interfaz XML
     */
    private void conectarElementosUI() {
        input = findViewById(R.id.inputIngrediente);
        btnGuardar = findViewById(R.id.btnGuardar);
        lista = findViewById(R.id.txtLista);
        btnUtensilios = findViewById(R.id.btnUtensilios);
        btnSugerencias = findViewById(R.id.btnSugerencias);
    }

    /**
     * Inicializa datos de ejemplo si la base de datos está vacía
     */
    private void inicializarDatos() {
        // Inicializar recetas de ejemplo
        gestorRecetas.inicializarRecetasDeEjemplo();

        // Inicializar utensilios básicos
        gestorUtensilios.inicializarUtensiliosBasicos();
    }

    /**
     * Configura los listeners para los botones
     */
    private void configurarListeners() {
        // Botón guardar ingrediente
        btnGuardar.setOnClickListener(v -> guardarIngrediente());

        // Botón ir a utensilios
        btnUtensilios.setOnClickListener(v -> irAUtensilios());

        // Botón ir a sugerencias
        btnSugerencias.setOnClickListener(v -> irASugerencias());
    }

    /**
     * Maneja el evento de guardar un ingrediente
     * ANTES: Toda esta lógica estaba aquí en MainActivity
     * AHORA: Solo capturamos el texto y llamamos al gestor
     */
    private void guardarIngrediente() {
        String nombre = input.getText().toString().trim();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa un ingrediente", Toast.LENGTH_SHORT).show();
            return;
        }

        // CLAVE: Llamamos al gestor para que maneje la lógica
        // La Activity solo se encarga de la interfaz
        String resultado = gestorIngredientes.agregarIngrediente(nombre);

        // Mostramos el resultado al usuario
        Toast.makeText(this, resultado, Toast.LENGTH_SHORT).show();

        // Actualizamos la lista en pantalla
        mostrarIngredientes();

        // Limpiamos el campo de texto
        input.setText("");
    }

    /**
     * Muestra la lista de ingredientes disponibles en pantalla
     * ANTES: Generábamos el texto aquí
     * AHORA: El gestor genera el texto formateado
     */
    private void mostrarIngredientes() {
        String listaFormateada = gestorIngredientes.generarListaDisponibles();
        lista.setText(listaFormateada);
    }

    /**
     * Navega a la pantalla de utensilios
     */
    private void irAUtensilios() {
        Intent intent = new Intent(MainActivity.this, UtensiliosActivity.class);
        startActivity(intent);
    }

    /**
     * Navega a la pantalla de sugerencias
     */
    private void irASugerencias() {
        Intent intent = new Intent(MainActivity.this, SugerenciasActivity.class);
        startActivity(intent);
    }

    /**
     * Se ejecuta cuando la Activity vuelve a estar visible
     * Actualizamos la lista por si cambió algo en otras pantallas
     */
    @Override
    protected void onResume() {
        super.onResume();
        mostrarIngredientes();
    }
}

package com.cookgpt;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Clase Utensilio: Representa un utensilio de cocina disponible para el usuario.
 *
 * PRINCIPIOS DE POO APLICADOS:
 * - Encapsulación: Atributos privados con getters/setters
 * - Comportamiento: Métodos propios del utensilio
 */
@Entity
public class Utensilio {
    // ============ ATRIBUTOS PRIVADOS ============
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String nombre;
    private boolean disponible;

    // ============ CONSTRUCTORES ============

    /**
     * Constructor vacío requerido por Room
     */
    public Utensilio() {
        this.disponible = false;
    }

    /**
     * Constructor con nombre
     */
    public Utensilio(String nombre) {
        this.nombre = nombre;
        this.disponible = false;
    }

    /**
     * Constructor completo
     */
    public Utensilio(String nombre, boolean disponible) {
        this.nombre = nombre;
        this.disponible = disponible;
    }

    // ============ MÉTODOS DE COMPORTAMIENTO ============

    /**
     * Marca este utensilio como disponible
     */
    public void marcarDisponible() {
        this.disponible = true;
    }

    /**
     * Marca este utensilio como no disponible
     */
    public void marcarNoDisponible() {
        this.disponible = false;
    }

    /**
     * Alterna el estado de disponibilidad
     */
    public void alternarDisponibilidad() {
        this.disponible = !this.disponible;
    }

    /**
     * Verifica si el nombre coincide con otro utensilio (ignorando mayúsculas)
     */
    public boolean coincideConNombre(String otroNombre) {
        if (this.nombre == null || otroNombre == null) {
            return false;
        }
        return this.nombre.toLowerCase().trim().equals(otroNombre.toLowerCase().trim());
    }

    /**
     * Verifica si el utensilio está activo y disponible para usar
     */
    public boolean estaActivo() {
        return this.disponible && this.nombre != null && !this.nombre.trim().isEmpty();
    }

    /**
     * Obtiene una representación visual del utensilio
     */
    public String obtenerRepresentacion() {
        String icono = this.disponible ? "✓" : "✗";
        return icono + " " + this.nombre;
    }

    // ============ GETTERS Y SETTERS ============

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            this.nombre = nombre.trim();
        }
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    // ============ MÉTODOS HEREDADOS DE OBJECT ============

    @Override
    public String toString() {
        return "Utensilio{" +
                "nombre='" + nombre + '\'' +
                ", disponible=" + disponible +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Utensilio otro = (Utensilio) obj;
        return coincideConNombre(otro.nombre);
    }

    @Override
    public int hashCode() {
        return nombre != null ? nombre.toLowerCase().hashCode() : 0;
    }
}

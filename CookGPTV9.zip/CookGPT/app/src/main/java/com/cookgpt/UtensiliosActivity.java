package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.content.Intent;
import androidx.room.Room;
import java.util.List;

/**
 * UtensiliosActivity: Pantalla para gestionar los utensilios disponibles.
 *
 * REFACTORIZACIÓN APLICADA:
 * - AHORA usa GestorUtensilios para toda la lógica
 * - Solo maneja la interfaz de usuario (checkboxes)
 */
public class UtensiliosActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private LinearLayout layoutUtensilios;
    private Button btnGuardar, btnVolver;

    // ===== GESTOR =====
    private GestorUtensilios gestorUtensilios;

    // ===== BASE DE DATOS =====
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utensilios);

        // Inicializar
        inicializarBaseDatos();
        inicializarGestor();
        conectarElementosUI();
        configurarListeners();

        // Cargar utensilios
        cargarUtensilios();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestor() {
        gestorUtensilios = new GestorUtensilios(db.utensilioDao());
    }

    private void conectarElementosUI() {
        layoutUtensilios = findViewById(R.id.layoutUtensilios);
        btnGuardar = findViewById(R.id.btnGuardarUtensilios);
        btnVolver = findViewById(R.id.btnVolverIngredientes);
    }

    private void configurarListeners() {
        btnGuardar.setOnClickListener(v -> {
            guardarUtensiliosSeleccionados();
            Toast.makeText(this, "Utensilios guardados correctamente", Toast.LENGTH_SHORT).show();
        });

        btnVolver.setOnClickListener(v -> {
            Intent i = new Intent(UtensiliosActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }

    /**
     * Carga todos los utensilios como checkboxes
     * ANTES: Accedía directamente al DAO y a los atributos públicos
     * AHORA: Usa el gestor y los getters
     */
    private void cargarUtensilios() {
        // Usar el gestor para obtener los utensilios
        List<Utensilio> utensilios = gestorUtensilios.obtenerTodos();

        for (Utensilio utensilio : utensilios) {
            CheckBox checkBox = new CheckBox(this);

            // USAR GETTERS en lugar de acceso directo
            checkBox.setText(utensilio.getNombre());
            checkBox.setChecked(utensilio.isDisponible());
            checkBox.setTag(utensilio.getId());

            layoutUtensilios.addView(checkBox);
        }
    }

    /**
     * Guarda el estado de los checkboxes en la base de datos
     * ANTES: Accedía directamente a los atributos y al DAO
     * AHORA: Usa el gestor y los métodos de comportamiento
     */
    private void guardarUtensiliosSeleccionados() {
        // Obtener todos los utensilios usando el gestor
        List<Utensilio> utensilios = gestorUtensilios.obtenerTodos();

        for (int i = 0; i < layoutUtensilios.getChildCount(); i++) {
            if (layoutUtensilios.getChildAt(i) instanceof CheckBox) {
                CheckBox checkBox = (CheckBox) layoutUtensilios.getChildAt(i);
                int utensilioId = (int) checkBox.getTag();
                boolean estaSeleccionado = checkBox.isChecked();

                // Buscar el utensilio correspondiente
                for (Utensilio u : utensilios) {
                    if (u.getId() == utensilioId) {
                        // USAR SETTER en lugar de acceso directo
                        u.setDisponible(estaSeleccionado);

                        // Usar el gestor para marcar disponibilidad
                        if (estaSeleccionado) {
                            gestorUtensilios.marcarDisponible(u);
                        } else {
                            gestorUtensilios.marcarNoDisponible(u);
                        }
                        break;
                    }
                }
            }
        }
    }
}

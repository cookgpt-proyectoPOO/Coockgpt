package com.cookgpt;

import java.util.ArrayList;
import java.util.List;

/**
 * GestorRecetas: Clase controladora que maneja toda la lógica de negocio relacionada
 * con las recetas.
 *
 * PRINCIPIO DE POO APLICADO:
 * - Separación de Responsabilidades (Single Responsibility Principle):
 *   Esta clase se encarga SOLO de la lógica de recetas, no de la interfaz de usuario.
 *
 * - Antes: La lógica estaba mezclada en las Activities (interfaz de usuario)
 * - Ahora: La lógica está aquí, las Activities solo manejan la UI
 *
 * BENEFICIOS:
 * - Código más fácil de probar (unit testing)
 * - Código reutilizable en diferentes pantallas
 * - Cambios en la lógica no afectan la interfaz
 */
public class GestorRecetas {

    private RecetaDao recetaDao;

    /**
     * Constructor: recibe el DAO para acceder a la base de datos
     */
    public GestorRecetas(RecetaDao recetaDao) {
        this.recetaDao = recetaDao;
    }

    // ============ MÉTODOS DE BÚSQUEDA Y FILTRADO ============

    /**
     * Obtiene todas las recetas de la base de datos
     */
    public List<Receta> obtenerTodasLasRecetas() {
        return recetaDao.getAll();
    }

    /**
     * Obtiene solo las recetas marcadas como favoritas
     */
    public List<Receta> obtenerRecetasFavoritas() {
        List<Receta> todas = recetaDao.getAll();
        List<Receta> favoritas = new ArrayList<>();

        for (Receta receta : todas) {
            if (receta.isFavorita()) {
                favoritas.add(receta);
            }
        }

        return favoritas;
    }

    /**
     * Busca recetas que se puedan preparar con los ingredientes y utensilios disponibles
     * ANTES: Este método estaba en SugerenciasActivity
     * AHORA: Está aquí porque es lógica de negocio, no lógica de interfaz
     */
    public List<Receta> obtenerRecetasPosibles(List<Ingrediente> ingredientesDisponibles,
                                               List<Utensilio> utensiliosDisponibles) {

        // Convertir a listas de nombres (strings) para facilitar la comparación
        List<String> nombresIngredientes = extraerNombresIngredientes(ingredientesDisponibles);
        List<String> nombresUtensilios = extraerNombresUtensilios(utensiliosDisponibles);

        // Obtener todas las recetas y filtrar las que se pueden hacer
        List<Receta> todasRecetas = recetaDao.getAll();
        List<Receta> recetasPosibles = new ArrayList<>();

        for (Receta receta : todasRecetas) {
            // Aquí usamos el método de la clase Receta (Orientación a Objetos!)
            if (receta.sePuedePreparar(nombresIngredientes, nombresUtensilios)) {
                recetasPosibles.add(receta);
            }
        }

        return recetasPosibles;
    }

    /**
     * Filtra recetas por categoría de tiempo
     */
    public List<Receta> filtrarPorTiempo(List<Receta> recetas, CategoríaTiempo categoría) {
        List<Receta> filtradas = new ArrayList<>();

        for (Receta receta : recetas) {
            boolean cumpleFiltro = false;

            switch (categoría) {
                case MUY_RAPIDO:
                    cumpleFiltro = receta.esMuyRapida();
                    break;
                case RAPIDO:
                    cumpleFiltro = receta.esRapida();
                    break;
                case MEDIO:
                    cumpleFiltro = receta.esTiempoMedio();
                    break;
                case NORMAL:
                    cumpleFiltro = receta.esTiempoNormal();
                    break;
                case LARGO:
                    cumpleFiltro = receta.esLarga();
                    break;
                case TODOS:
                    cumpleFiltro = true;
                    break;
            }

            if (cumpleFiltro) {
                filtradas.add(receta);
            }
        }

        return filtradas;
    }

    /**
     * Busca recetas que contengan un ingrediente específico
     */
    public List<Receta> buscarPorIngrediente(String ingrediente) {
        List<Receta> todas = recetaDao.getAll();
        List<Receta> resultado = new ArrayList<>();

        for (Receta receta : todas) {
            if (receta.requiereIngrediente(ingrediente)) {
                resultado.add(receta);
            }
        }

        return resultado;
    }

    /**
     * Busca recetas que requieran un utensilio específico
     */
    public List<Receta> buscarPorUtensilio(String utensilio) {
        List<Receta> todas = recetaDao.getAll();
        List<Receta> resultado = new ArrayList<>();

        for (Receta receta : todas) {
            if (receta.requiereUtensilio(utensilio)) {
                resultado.add(receta);
            }
        }

        return resultado;
    }

    // ============ MÉTODOS DE GESTIÓN DE RECETAS ============

    /**
     * Guarda una receta nueva en la base de datos
     */
    public void guardarReceta(Receta receta) {
        if (receta != null && receta.getNombre() != null && !receta.getNombre().isEmpty()) {
            recetaDao.insertar(receta);
        }
    }

    /**
     * Marca o desmarca una receta como favorita
     */
    public void toggleFavorita(Receta receta) {
        if (receta != null && receta.getId() > 0) {
            receta.alternarFavorita();
            // Usar el método específico que SÍ existe en tu DAO
            recetaDao.updateFavorita(receta.getId(), receta.isFavorita());
        }
    }

    // ============ MÉTODOS DE INICIALIZACIÓN ============

    /**
     * Verifica si hay recetas en la base de datos
     */
    public boolean hayRecetasGuardadas() {
        List<Receta> recetas = recetaDao.getAll();
        return recetas != null && !recetas.isEmpty();
    }

    /**
     * Inicializa la base de datos con recetas de ejemplo si está vacía
     */
    public void inicializarRecetasDeEjemplo() {
        if (!hayRecetasGuardadas()) {
            agregarRecetasDeEjemplo();
        }
    }

    // ============ MÉTODOS AUXILIARES PRIVADOS ============

    /**
     * Extrae los nombres de una lista de ingredientes
     */
    private List<String> extraerNombresIngredientes(List<Ingrediente> ingredientes) {
        List<String> nombres = new ArrayList<>();
        for (Ingrediente ing : ingredientes) {
            if (ing.isDisponible()) {
                nombres.add(ing.getNombre().toLowerCase().trim());
            }
        }
        return nombres;
    }

    /**
     * Extrae los nombres de una lista de utensilios
     */
    private List<String> extraerNombresUtensilios(List<Utensilio> utensilios) {
        List<String> nombres = new ArrayList<>();
        for (Utensilio ut : utensilios) {
            if (ut.isDisponible()) {
                nombres.add(ut.getNombre().toLowerCase().trim());
            }
        }
        return nombres;
    }

    /**
     * Agrega las recetas de ejemplo a la base de datos
     * (Mismo código que tenías en MainActivity, pero ahora aquí)
     */
    private void agregarRecetasDeEjemplo() {
        // ========== DESAYUNOS ==========

        Receta r1 = new Receta("Huevos revueltos con pan",
                "huevos,sal,aceite,pan",
                "sarten,tenedor",
                "\n1. Batir los huevos con sal (1 min)\n2. Calentar aceite en sartén (1 min)\n3. Verter huevos y revolver (1 min)\n4. Tostar el pan (1 min)\n5. Servir los huevos sobre el pan (2 min)",
                7);
        recetaDao.insertar(r1);

        Receta r2 = new Receta("Avena con fruta",
                "avena,agua,leche,fruta",
                "cazo,cuchara",
                "\n1. Poner avena y agua/leche a calentar (2 min)\n2. Cocer hasta que espese (2 min)\n3. Agregar fruta picada (2 min)\n4. Servir en tazón (2 min)",
                10);
        recetaDao.insertar(r2);

        Receta r3 = new Receta("Tostadas con aguacate",
                "pan,aguacate,sal,limon",
                "cuchillo,tenedor",
                "\n1. Tostar el pan (1 min)\n2. Machacar el aguacate con sal y limón (1 min)\n3. Untar aguacate sobre el pan (1 min)\n4. Servir (3 min)",
                7);
        recetaDao.insertar(r3);

        Receta r4 = new Receta("Sándwich de jamón y queso",
                "pan,jamon,queso",
                "sarten,espatula",
                "\n1. Colocar jamón y queso entre los panes (2 min)\n2. Tostar hasta que se derrita el queso (2 min)\n3. Servir (2 min)",
                8);
        recetaDao.insertar(r4);

        Receta r5 = new Receta("Hot cakes rápidos",
                "huevo,harina,leche,azucar",
                "sarten,cuchara",
                "\n1. Mezclar ingredientes hasta formar masa (2 min)\n2. Calentar sartén (2 min)\n3. Verter masa y cocinar por ambos lados (2 min)\n4. Servir con miel o mermelada (5 min)",
                12);
        recetaDao.insertar(r5);

        Receta r6 = new Receta("Yogur con granola y miel",
                "yogur,granola,miel",
                "tazon,cuchara",
                "\n1. Verter yogur en tazón (1 min)\n2. Agregar granola (1 min)\n3. Añadir miel encima (2 min)",
                5);
        recetaDao.insertar(r6);

        Receta r7 = new Receta("Huevos duros",
                "huevos,agua,sal",
                "cazo,cuchara",
                "\n1. Colocar huevos en cazo con agua (3 min)\n2. Hervir 8 minutos (3 min)\n3. Enfriar y pelar (3 min)",
                10);
        recetaDao.insertar(r7);

        Receta r8 = new Receta("Pan con crema de maní y plátano",
                "pan,crema de mani,platano",
                "cuchillo",
                "\n1. Untar crema en pan (1 min)\n2. Cortar plátano en rodajas (1 min)\n3. Colocar sobre el pan (3 min)",
                6);
        recetaDao.insertar(r8);

        Receta r9 = new Receta("Batido energético",
                "platano,leche,avena,miel",
                "licuadora",
                "\n1. Colocar ingredientes en licuadora (2 min)\n2. Licuar hasta homogeneizar (2 min)\n3. Servir (2 min)",
                7);
        recetaDao.insertar(r9);

        Receta r10 = new Receta("Quesadilla de queso",
                "tortilla,queso",
                "sarten,espatula",
                "\n1. Calentar sartén (1 min)\n2. Colocar tortilla con queso (1 min)\n3. Doblar y dorar ambos lados (1 min)\n4. Servir (2 min)",
                6);
        recetaDao.insertar(r10);

        // ========== ALMUERZOS ==========

        Receta r11 = new Receta("Arroz con huevo",
                "arroz,huevo,aceite,sal",
                "olla,sarten",
                "\n1. Cocer arroz (4 min)\n2. Freír huevo (4 min)\n3. Servir arroz con huevo encima (5 min)",
                15);
        recetaDao.insertar(r11);

        Receta r12 = new Receta("Pasta con salsa de tomate",
                "pasta,salsa de tomate,sal",
                "olla,cuchara",
                "\n1. Cocer pasta (5 min)\n2. Calentar salsa (5 min)\n3. Mezclar y servir (6 min)",
                18);
        recetaDao.insertar(r12);

        Receta r13 = new Receta("Tacos de atún",
                "atun,tortilla,limon,mayonesa",
                "cuchara",
                "\n1. Mezclar atún con limón y mayonesa (2 min)\n2. Colocar en tortillas (2 min)\n3. Servir (3 min)",
                8);
        recetaDao.insertar(r13);

        Receta r14 = new Receta("Arroz frito con verduras",
                "arroz,verduras,salsa soya",
                "sarten,cuchara",
                "\n1. Saltear verduras (2 min)\n2. Agregar arroz (2 min)\n3. Añadir salsa soya (2 min)\n4. Servir (5 min)",
                12);
        recetaDao.insertar(r14);

        Receta r15 = new Receta("Pollo al sartén",
                "pechuga de pollo,sal,aceite,limon",
                "sarten,pinzas",
                "\n1. Sazonar pollo (5 min)\n2. Cocinar por ambos lados (5 min)\n3. Servir con limón (7 min)",
                20);
        recetaDao.insertar(r15);

        Receta r16 = new Receta("Ensalada de atún",
                "atun,lechuga,tomate,limon",
                "tazon,tenedor",
                "\n1. Picar verduras (2 min)\n2. Agregar atún (2 min)\n3. Mezclar con limón (4 min)",
                9);
        recetaDao.insertar(r16);

        Receta r17 = new Receta("Huevos con frijoles",
                "huevos,frijoles,aceite",
                "sarten",
                "\n1. Freír huevos (3 min)\n2. Calentar frijoles (3 min)\n3. Servir juntos (3 min)",
                10);
        recetaDao.insertar(r17);

        Receta r18 = new Receta("Sándwich de pollo",
                "pan,pollo,mayonesa",
                "cuchillo",
                "\n1. Mezclar pollo con mayonesa (2 min)\n2. Colocar entre panes (2 min)\n3. Servir (3 min)",
                8);
        recetaDao.insertar(r18);

        Receta r19 = new Receta("Papas fritas con huevo",
                "papas,huevo,aceite,sal",
                "sarten,cuchillo",
                "\n1. Cortar papas (3 min)\n2. Freír hasta dorar (3 min)\n3. Agregar huevo y cocinar (3 min)\n4. Servir (4 min)",
                15);
        recetaDao.insertar(r19);

        Receta r20 = new Receta("Wrap de jamón",
                "tortilla,jamon,lechuga,mayonesa",
                "cuchillo",
                "\n1. Untar mayonesa (1 min)\n2. Colocar ingredientes (1 min)\n3. Enrollar tortilla (1 min)\n4. Servir (4 min)",
                8);
        recetaDao.insertar(r20);

        // ========== CENAS ==========

        Receta r21 = new Receta("Sopa instantánea con huevo",
                "sopa instantanea,huevo",
                "olla,cuchara",
                "\n1. Hervir agua (1 min)\n2. Agregar sopa (1 min)\n3. Romper huevo y cocer (1 min)\n4. Servir (3 min)",
                8);
        recetaDao.insertar(r21);

        Receta r22 = new Receta("Arroz con verduras",
                "arroz,verduras",
                "olla,cuchara",
                "\n1. Cocer arroz (4 min)\n2. Agregar verduras (4 min)\n3. Sazonar al gusto (5 min)",
                15);
        recetaDao.insertar(r22);

        Receta r23 = new Receta("Tostadas con frijoles",
                "tostadas,frijoles,queso",
                "cuchillo",
                "\n1. Untar frijoles (2 min)\n2. Agregar queso (2 min)\n3. Servir (4 min)",
                9);
        recetaDao.insertar(r23);

        Receta r24 = new Receta("Quesadilla de jamón",
                "tortilla,jamon,queso",
                "sarten,espatula",
                "\n1. Colocar ingredientes (2 min)\n2. Doblar tortilla (2 min)\n3. Calentar hasta derretir (3 min)",
                8);
        recetaDao.insertar(r24);

        Receta r25 = new Receta("Puré de papa con atún",
                "papas,atun,sal,mantequilla",
                "olla,tenedor",
                "\n1. Cocer papas (4 min)\n2. Machacar con mantequilla (4 min)\n3. Agregar atún (5 min)",
                15);
        recetaDao.insertar(r25);

        Receta r26 = new Receta("Huevos a la mexicana",
                "huevos,tomate,cebolla,chile",
                "sarten,cuchillo",
                "\n1. Picar verduras (3 min)\n2. Sofreír (3 min)\n3. Agregar huevos y cocinar (3 min)",
                10);
        recetaDao.insertar(r26);

        Receta r27 = new Receta("Pasta con mantequilla",
                "pasta,mantequilla,sal",
                "olla,sarten",
                "\n1. Cocer pasta (3 min)\n2. Agregar mantequilla derretida (3 min)\n3. Servir (5 min)",
                12);
        recetaDao.insertar(r27);

        Receta r28 = new Receta("Sopa de verduras",
                "verduras,agua,sal",
                "olla,cuchara",
                "\n1. Hervir agua (5 min)\n2. Agregar verduras (5 min)\n3. Cocer hasta tiernas (7 min)",
                20);
        recetaDao.insertar(r28);

        Receta r29 = new Receta("Tortilla francesa",
                "huevos,sal,aceite",
                "sarten,tenedor",
                "\n1. Batir huevos (2 min)\n2. Verter y enrollar en sartén (2 min)\n3. Servir (4 min)",
                9);
        recetaDao.insertar(r29);

        Receta r30 = new Receta("Pan con queso fundido",
                "pan,queso,mantequilla",
                "sarten,espatula",
                "\n1. Untar mantequilla (2 min)\n2. Agregar queso (2 min)\n3. Tostar hasta fundir (3 min)",
                8);
        recetaDao.insertar(r30);

        // ========== SNACKS ==========

        Receta r31 = new Receta("Palomitas de microondas",
                "palomitas",
                "microondas,tazon",
                "\n1. Colocar bolsa en microondas (1 min)\n2. Cocinar según instrucciones (1 min)\n3. Servir (2 min)",
                5);
        recetaDao.insertar(r31);

        Receta r32 = new Receta("Sandía con limón",
                "sandia,limon",
                "cuchillo",
                "\n1. Cortar sandía (1 min)\n2. Agregar limón (1 min)\n3. Servir (0 min)",
                3);
        recetaDao.insertar(r32);

        Receta r33 = new Receta("Galletas con yogur",
                "galletas,yogur",
                "cuchara",
                "\n1. Colocar galletas (1 min)\n2. Servir yogur encima (2 min)",
                4);
        recetaDao.insertar(r33);

        Receta r34 = new Receta("Pan con mermelada",
                "pan,mermelada",
                "cuchillo",
                "\n1. Tostar pan (1 min)\n2. Untar mermelada (1 min)\n3. Servir (1 min)",
                4);
        recetaDao.insertar(r34);

        Receta r35 = new Receta("Fruta picada",
                "manzana,platano,melon",
                "cuchillo,tazon",
                "\n1. Pelar frutas (1 min)\n2. Cortar en trozos (1 min)\n3. Servir (3 min)",
                6);
        recetaDao.insertar(r35);

        Receta r36 = new Receta("Cereal con leche",
                "cereal,leche",
                "tazon,cuchara",
                "\n1. Verter cereal (1 min)\n2. Agregar leche (1 min)",
                3);
        recetaDao.insertar(r36);

        Receta r37 = new Receta("Nachos con queso",
                "totopos,queso",
                "microondas",
                "\n1. Colocar totopos (2 min)\n2. Agregar queso (2 min)\n3. Calentar hasta fundir (2 min)",
                7);
        recetaDao.insertar(r37);

        Receta r38 = new Receta("Plátano con miel",
                "platano,miel",
                "cuchillo",
                "\n1. Cortar plátano (1 min)\n2. Agregar miel (1 min)",
                3);
        recetaDao.insertar(r38);

        Receta r39 = new Receta("Tostadas de crema y azúcar",
                "pan,mantequilla,azucar",
                "sarten,cuchillo",
                "\n1. Untar mantequilla (1 min)\n2. Espolvorear azúcar (1 min)\n3. Tostar (3 min)",
                6);
        recetaDao.insertar(r39);

        Receta r40 = new Receta("Gelatina lista",
                "gelatina",
                "cuchara,tazon",
                "\n1. Servir en tazón (1 min)\n2. Comer (0 min)",
                2);
        recetaDao.insertar(r40);
    }

    // ============ ENUM PARA CATEGORÍAS DE TIEMPO ============

    /**
     * Enum que define las categorías de tiempo disponibles para filtrar
     * Esto es más seguro y claro que usar strings o números mágicos
     */
    public enum CategoríaTiempo {
        TODOS,
        MUY_RAPIDO,  // < 5 min
        RAPIDO,      // 5-10 min
        MEDIO,       // 10-15 min
        NORMAL,      // 15-20 min
        LARGO        // > 20 min
    }
}

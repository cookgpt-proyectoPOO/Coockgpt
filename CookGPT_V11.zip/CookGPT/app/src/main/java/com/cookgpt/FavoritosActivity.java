package com.cookgpt;

public class FavoritosActivity {
}

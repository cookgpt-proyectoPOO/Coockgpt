package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import androidx.room.Room;

/**
 * RegistroActivity: Pantalla para registrar nuevos usuarios.
 */
public class RegistroActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private EditText txtUsername, txtPassword, txtPasswordConfirm, txtEmail;
    private Button btnRegistrar, btnVolver;
    private TextView txtMensaje;

    // ===== GESTORES =====
    private GestorUsuario gestorUsuarios;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        inicializarBaseDatos();
        inicializarGestor();
        conectarElementosUI();
        configurarListeners();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestor() {
        gestorUsuarios = new GestorUsuario(db.usuarioDao());
    }

    private void conectarElementosUI() {
        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);
        txtPasswordConfirm = findViewById(R.id.txtPasswordConfirm);
        txtEmail = findViewById(R.id.txtEmail);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        btnVolver = findViewById(R.id.btnVolver);
        txtMensaje = findViewById(R.id.txtMensaje);
    }

    private void configurarListeners() {
        btnRegistrar.setOnClickListener(v -> intentarRegistro());
        btnVolver.setOnClickListener(v -> finish());
    }

    /**
     * Intenta registrar un nuevo usuario
     */
    private void intentarRegistro() {
        String username = txtUsername.getText().toString().trim();
        String password = txtPassword.getText().toString();
        String passwordConfirm = txtPasswordConfirm.getText().toString();
        String email = txtEmail.getText().toString().trim();

        // Validar campos vacíos
        if (username.isEmpty() || password.isEmpty() ||
                passwordConfirm.isEmpty() || email.isEmpty()) {
            mostrarMensaje("Por favor completa todos los campos", false);
            return;
        }

        // Validar que las contraseñas coincidan
        if (!password.equals(passwordConfirm)) {
            mostrarMensaje("Las contraseñas no coinciden", false);
            return;
        }

        // Intentar registrar usando el gestor
        String resultado = gestorUsuarios.registrarUsuario(username, password, email);

        // Verificar si el registro fue exitoso
        if (resultado.startsWith("¡Usuario registrado")) {
            mostrarMensaje(resultado, true);
            Toast.makeText(this, resultado, Toast.LENGTH_LONG).show();

            // Esperar 1 segundo y volver al login
            new android.os.Handler().postDelayed(() -> {
                finish();
            }, 1500);
        } else {
            mostrarMensaje(resultado, false);
        }
    }

    /**
     * Muestra un mensaje en el TextView
     */
    private void mostrarMensaje(String mensaje, boolean esExito) {
        txtMensaje.setText(mensaje);
        txtMensaje.setTextColor(esExito ?
                getResources().getColor(android.R.color.holo_green_dark) :
                getResources().getColor(android.R.color.holo_red_dark));
    }
}
package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import androidx.room.Room;
import android.content.Intent;
import android.graphics.Typeface;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * HistorialActivity: Muestra el historial de recetas vistas por el usuario.
 */
public class HistorialActivity extends AppCompatActivity {

    private LinearLayout layoutHistorial;
    private TextView txtTitulo;
    private Button btnVolver, btnLimpiar;

    private AppDatabase db;
    private SesionManager sesionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        inicializarBaseDatos();
        sesionManager = new SesionManager(this);
        conectarElementosUI();
        configurarListeners();
        cargarHistorial();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void conectarElementosUI() {
        txtTitulo = findViewById(R.id.txtTituloHistorial);
        layoutHistorial = findViewById(R.id.layoutHistorial);
        btnVolver = findViewById(R.id.btnVolverHistorial);
        btnLimpiar = findViewById(R.id.btnLimpiarHistorial);
    }

    private void configurarListeners() {
        btnVolver.setOnClickListener(v -> finish());
        btnLimpiar.setOnClickListener(v -> confirmarLimpiarHistorial());
    }

    private void cargarHistorial() {
        layoutHistorial.removeAllViews();

        String username = sesionManager.getUsername();
        List<HistorialReceta> historial = db.historialRecetaDao()
                .obtenerPorUsuario(username);

        if (historial.isEmpty()) {
            mostrarMensajeVacio();
        } else {
            txtTitulo.setText("Mi Historial (" + historial.size() + " recetas)");

            // Mostrar en orden inverso (más reciente primero)
            for (int i = historial.size() - 1; i >= 0; i--) {
                HistorialReceta item = historial.get(i);
                agregarItemHistorial(item);
            }
        }
    }

    private void agregarItemHistorial(HistorialReceta item) {
        // Crear card para el item
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        card.setBackgroundColor(getResources().getColor(android.R.color.white));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 15);
        card.setLayoutParams(params);

        // Nombre de la receta
        TextView txtNombre = new TextView(this);
        txtNombre.setText("📖 " + item.getNombreReceta());
        txtNombre.setTextSize(18);
        txtNombre.setTypeface(null, Typeface.BOLD);
        card.addView(txtNombre);

        // Fecha
        TextView txtFecha = new TextView(this);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        String fechaStr = sdf.format(new Date(item.getFechaVista()));
        txtFecha.setText("🕐 " + fechaStr);
        txtFecha.setTextSize(14);
        txtFecha.setPadding(0, 5, 0, 10);
        card.addView(txtFecha);

        // Botón ver detalles
        Button btnVer = new Button(this);
        btnVer.setText("Ver Receta");
        btnVer.setOnClickListener(v -> abrirDetalleReceta(item));
        card.addView(btnVer);

        layoutHistorial.addView(card);
    }

    private void abrirDetalleReceta(HistorialReceta item) {
        Receta receta = db.recetaDao().getByNombre(item.getNombreReceta());

        if (receta != null) {
            Intent intent = new Intent(this, DetalleRecetaActivity.class);
            intent.putExtra("nombre", receta.getNombre());
            intent.putExtra("pasos", receta.getPasos());
            intent.putExtra("tiempo", receta.getTiempo());
            intent.putExtra("recetaId", receta.getId());
            startActivity(intent);
        } else {
            Toast.makeText(this, "Receta no encontrada", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarMensajeVacio() {
        TextView txtVacio = new TextView(this);
        txtVacio.setText("No has visto ninguna receta aún.\n\n¡Explora las sugerencias para empezar!");
        txtVacio.setTextSize(16);
        txtVacio.setGravity(android.view.Gravity.CENTER);
        txtVacio.setPadding(40, 40, 40, 40);
        layoutHistorial.addView(txtVacio);

        btnLimpiar.setEnabled(false);
    }

    private void confirmarLimpiarHistorial() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Limpiar Historial")
                .setMessage("¿Estás seguro de que quieres eliminar todo tu historial?")
                .setPositiveButton("Sí, eliminar", (dialog, which) -> limpiarHistorial())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void limpiarHistorial() {
        String username = sesionManager.getUsername();
        db.historialRecetaDao().eliminarPorUsuario(username);
        Toast.makeText(this, "Historial eliminado", Toast.LENGTH_SHORT).show();
        cargarHistorial();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarHistorial();
    }
}
package com.cookgpt;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * HistorialReceta: Registra las recetas que el usuario ha visto.
 */
@Entity
public class HistorialReceta {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String username;
    private String nombreReceta;
    private long fechaVista;  // timestamp en milisegundos

    public HistorialReceta() {}

    public HistorialReceta(String username, String nombreReceta) {
        this.username = username;
        this.nombreReceta = nombreReceta;
        this.fechaVista = System.currentTimeMillis();
    }

    // ============ GETTERS Y SETTERS ============

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNombreReceta() {
        return nombreReceta;
    }

    public void setNombreReceta(String nombreReceta) {
        this.nombreReceta = nombreReceta;
    }

    public long getFechaVista() {
        return fechaVista;
    }

    public void setFechaVista(long fechaVista) {
        this.fechaVista = fechaVista;
    }
}
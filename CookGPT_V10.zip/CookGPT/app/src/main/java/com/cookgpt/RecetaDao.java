package com.cookgpt;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface RecetaDao {
    @Insert
    void insertar(Receta r);

    @Query("SELECT * FROM Receta")
    List<Receta> getAll();

    // NUEVO: obtener por nombre (para no tocar otras pantallas que no mandan id)
    @Query("SELECT * FROM Receta WHERE nombre = :nombre LIMIT 1")
    Receta getByNombre(String nombre);

    // NUEVO: marcar/desmarcar favorito
    @Query("UPDATE Receta SET favorita = :favorita WHERE id = :id")
    void updateFavorita(int id, boolean favorita);

    // Opcional (por si luego haces una pantalla de favoritos)
    @Query("SELECT * FROM Receta WHERE favorita = 1")
    List<Receta> getFavoritas();
}
package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import androidx.room.Room;
import java.util.List;

/**
 * AdminActivity: Panel de administración.
 * Solo accesible para usuarios con rol de administrador.
 */
public class AdminActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private TextView txtEstadisticas, txtListaUsuarios;
    private Button btnVolver, btnActualizar;
    private LinearLayout layoutUsuarios;

    // ===== GESTORES =====
    private GestorUsuarios gestorUsuarios;
    private GestorRecetas gestorRecetas;
    private SesionManager sesionManager;

    // ===== BASE DE DATOS =====
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Verificar permisos de admin
        sesionManager = new SesionManager(this);
        if (!sesionManager.esAdministrador()) {
            Toast.makeText(this, "Acceso denegado: Solo administradores", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin);

        inicializarBaseDatos();
        inicializarGestores();
        conectarElementosUI();
        configurarListeners();
        cargarDatos();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestores() {
        gestorUsuarios = new GestorUsuarios(db.usuarioDao());
        gestorRecetas = new GestorRecetas(db.recetaDao());
    }

    private void conectarElementosUI() {
        txtEstadisticas = findViewById(R.id.txtEstadisticas);
        layoutUsuarios = findViewById(R.id.layoutUsuarios);
        btnVolver = findViewById(R.id.btnVolver);
        btnActualizar = findViewById(R.id.btnActualizar);
    }

    private void configurarListeners() {
        btnVolver.setOnClickListener(v -> finish());
        btnActualizar.setOnClickListener(v -> cargarDatos());
    }

    /**
     * Carga todas las estadísticas y lista de usuarios
     */
    private void cargarDatos() {
        cargarEstadisticas();
        cargarListaUsuarios();
    }

    /**
     * Muestra estadísticas generales del sistema
     */
    private void cargarEstadisticas() {
        String estadisticas = gestorUsuarios.obtenerEstadisticas();

        // Agregar info de recetas
        int totalRecetas = gestorRecetas.obtenerTodasLasRecetas().size();
        estadisticas += "\nTotal de recetas: " + totalRecetas;

        txtEstadisticas.setText(estadisticas);
    }

    /**
     * Muestra la lista de todos los usuarios con opciones
     */
    private void cargarListaUsuarios() {
        layoutUsuarios.removeAllViews();

        List<Usuario> usuarios = gestorUsuarios.obtenerTodos();
        String usernameActual = sesionManager.getUsername();

        for (Usuario usuario : usuarios) {
            // Crear un card para cada usuario
            LinearLayout cardUsuario = new LinearLayout(this);
            cardUsuario.setOrientation(LinearLayout.VERTICAL);
            cardUsuario.setPadding(20, 20, 20, 20);
            cardUsuario.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 0, 0, 15);
            cardUsuario.setLayoutParams(params);

            // Info del usuario
            TextView txtInfo = new TextView(this);
            String rol = usuario.isEsAdministrador() ? " [ADMIN]" : " [Usuario]";
            String esYo = usuario.getUsername().equals(usernameActual) ? " (Tú)" : "";
            txtInfo.setText("👤 " + usuario.getUsername() + rol + esYo + "\n📧 " + usuario.getEmail());
            txtInfo.setTextSize(16);
            txtInfo.setPadding(0, 0, 0, 10);
            cardUsuario.addView(txtInfo);

            // Botones de acciones (solo si no es el usuario actual)
            if (!usuario.getUsername().equals(usernameActual)) {
                LinearLayout layoutBotones = new LinearLayout(this);
                layoutBotones.setOrientation(LinearLayout.HORIZONTAL);

                // Botón cambiar rol
                Button btnCambiarRol = new Button(this);
                if (usuario.isEsAdministrador()) {
                    btnCambiarRol.setText("Quitar Admin");
                    btnCambiarRol.setOnClickListener(v -> quitarAdmin(usuario));
                } else {
                    btnCambiarRol.setText("Hacer Admin");
                    btnCambiarRol.setOnClickListener(v -> hacerAdmin(usuario));
                }
                btnCambiarRol.setTextSize(12);
                layoutBotones.addView(btnCambiarRol);

                // Botón eliminar (solo si no es el único admin)
                Button btnEliminar = new Button(this);
                btnEliminar.setText("Eliminar");
                btnEliminar.setTextSize(12);
                btnEliminar.setOnClickListener(v -> confirmarEliminar(usuario));
                layoutBotones.addView(btnEliminar);

                cardUsuario.addView(layoutBotones);
            }

            layoutUsuarios.addView(cardUsuario);
        }
    }

    /**
     * Hace a un usuario administrador
     */
    private void hacerAdmin(Usuario usuario) {
        Usuario usuarioActual = db.usuarioDao().buscarPorUsername(sesionManager.getUsername());
        String resultado = gestorUsuarios.hacerAdministrador(usuario, usuarioActual);
        Toast.makeText(this, resultado, Toast.LENGTH_SHORT).show();
        cargarDatos();
    }

    /**
     * Quita privilegios de admin a un usuario
     */
    private void quitarAdmin(Usuario usuario) {
        Usuario usuarioActual = db.usuarioDao().buscarPorUsername(sesionManager.getUsername());
        String resultado = gestorUsuarios.quitarAdministrador(usuario, usuarioActual);
        Toast.makeText(this, resultado, Toast.LENGTH_SHORT).show();
        cargarDatos();
    }

    /**
     * Confirma antes de eliminar un usuario
     */
    private void confirmarEliminar(Usuario usuario) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Confirmar eliminación")
                .setMessage("¿Estás seguro de eliminar al usuario " + usuario.getUsername() + "?")
                .setPositiveButton("Eliminar", (dialog, which) -> eliminarUsuario(usuario))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Elimina un usuario
     */
    private void eliminarUsuario(Usuario usuario) {
        Usuario usuarioActual = db.usuarioDao().buscarPorUsername(sesionManager.getUsername());
        String resultado = gestorUsuarios.eliminarUsuario(usuario, usuarioActual);
        Toast.makeText(this, resultado, Toast.LENGTH_LONG).show();

        if (resultado.contains("exitosamente")) {
            cargarDatos();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }
}
package com.cookgpt;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

/**
 * UsuarioDao: Interface para acceder a la tabla Usuario en la base de datos.
 */
@Dao
public interface UsuarioDao {

    /**
     * Inserta un nuevo usuario en la base de datos
     */
    @Insert
    void insertar(Usuario usuario);

    /**
     * Actualiza un usuario existente
     */
    @Update
    void actualizar(Usuario usuario);

    /**
     * Obtiene todos los usuarios
     */
    @Query("SELECT * FROM Usuario")
    List<Usuario> getAll();

    /**
     * Busca un usuario por su username
     */
    @Query("SELECT * FROM Usuario WHERE username = :username LIMIT 1")
    Usuario buscarPorUsername(String username);

    /**
     * Busca un usuario por su email
     */
    @Query("SELECT * FROM Usuario WHERE email = :email LIMIT 1")
    Usuario buscarPorEmail(String email);

    /**
     * Busca un usuario por username y password (para login)
     */
    @Query("SELECT * FROM Usuario WHERE username = :username AND password = :password LIMIT 1")
    Usuario login(String username, String password);

    /**
     * Obtiene todos los administradores
     */
    @Query("SELECT * FROM Usuario WHERE esAdministrador = 1")
    List<Usuario> getAdministradores();

    /**
     * Obtiene todos los usuarios normales (no admin)
     */
    @Query("SELECT * FROM Usuario WHERE esAdministrador = 0")
    List<Usuario> getUsuariosNormales();

    /**
     * Cuenta cuántos usuarios hay en total
     */
    @Query("SELECT COUNT(*) FROM Usuario")
    int contarUsuarios();
}
package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.content.Intent;
import androidx.room.Room;

/**
 * LoginActivity: Pantalla de inicio de sesión.
 * Esta será la primera pantalla que verá el usuario.
 */
public class LoginActivity extends AppCompatActivity {

    // ===== COMPONENTES DE LA INTERFAZ =====
    private EditText txtUsername, txtPassword;
    private Button btnLogin, btnIrARegistro;
    private TextView txtMensaje;

    // ===== GESTORES Y MANAGERS =====
    private GestorUsuario gestorUsuarios;
    private SesionManager sesionManager;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar managers
        sesionManager = new SesionManager(this);

        // Si ya hay sesión activa, ir directo al MainActivity
        if (sesionManager.hayUsuarioLogueado()) {
            irAMain();
            return;
        }

        setContentView(R.layout.activity_login);

        inicializarBaseDatos();
        inicializarGestor();
        conectarElementosUI();
        configurarListeners();
    }

    private void inicializarBaseDatos() {
        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
    }

    private void inicializarGestor() {
        gestorUsuarios = new GestorUsuario(db.usuarioDao());
    }

    private void conectarElementosUI() {
        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnIrARegistro = findViewById(R.id.btnIrARegistro);
        txtMensaje = findViewById(R.id.txtMensaje);
    }

    private void configurarListeners() {
        btnLogin.setOnClickListener(v -> intentarLogin());
        btnIrARegistro.setOnClickListener(v -> irARegistro());
    }

    /**
     * Intenta hacer login con las credenciales ingresadas
     */
    private void intentarLogin() {
        String username = txtUsername.getText().toString().trim();
        String password = txtPassword.getText().toString();

        // Validar campos vacíos
        if (username.isEmpty() || password.isEmpty()) {
            mostrarMensaje("Por favor completa todos los campos", false);
            return;
        }

        // Intentar hacer login usando el gestor
        Usuario usuario = gestorUsuarios.iniciarSesion(username, password);

        if (usuario != null) {
            // Login exitoso
            sesionManager.iniciarSesion(usuario);

            String mensaje = usuario.esAdmin() ?
                    "¡Bienvenido Admin " + usuario.getUsername() + "!" :
                    "¡Bienvenido " + usuario.getUsername() + "!";

            Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
            irAMain();
        } else {
            // Login fallido
            mostrarMensaje("Usuario o contraseña incorrectos", false);
        }
    }

    /**
     * Navega a la pantalla de registro
     */
    private void irARegistro() {
        Intent intent = new Intent(LoginActivity.this, RegistroActivity.class);
        startActivity(intent);
    }

    /**
     * Navega al MainActivity
     */
    private void irAMain() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Cerrar LoginActivity para que no pueda volver con el botón atrás
    }

    /**
     * Muestra un mensaje en el TextView
     */
    private void mostrarMensaje(String mensaje, boolean esExito) {
        txtMensaje.setText(mensaje);
        txtMensaje.setTextColor(esExito ?
                getResources().getColor(android.R.color.holo_green_dark) :
                getResources().getColor(android.R.color.holo_red_dark));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Limpiar campos al volver a la pantalla
        txtUsername.setText("");
        txtPassword.setText("");
        txtMensaje.setText("");
    }
}
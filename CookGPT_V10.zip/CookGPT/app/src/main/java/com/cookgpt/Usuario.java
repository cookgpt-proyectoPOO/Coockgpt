package com.cookgpt;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Clase Usuario: Representa un usuario del sistema con login.
 *
 * PRINCIPIOS POO:
 * - Encapsulación: Atributos privados
 * - Comportamiento: Métodos para validar contraseñas, verificar roles
 */
@Entity
public class Usuario {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String username;
    private String password;
    private String email;
    private boolean esAdministrador;  // true = admin, false = usuario normal

    // ============ CONSTRUCTORES ============

    /**
     * Constructor vacío requerido por Room
     */
    public Usuario() {
        this.esAdministrador = false;  // Por defecto es usuario normal
    }

    /**
     * Constructor para crear un usuario nuevo
     */
    public Usuario(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.esAdministrador = false;
    }

    /**
     * Constructor completo (incluyendo rol)
     */
    public Usuario(String username, String password, String email, boolean esAdministrador) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.esAdministrador = esAdministrador;
    }

    // ============ MÉTODOS DE COMPORTAMIENTO ============

    /**
     * Verifica si la contraseña proporcionada es correcta
     */
    public boolean verificarPassword(String passwordIngresada) {
        return this.password != null && this.password.equals(passwordIngresada);
    }

    /**
     * Verifica si este usuario es administrador
     */
    public boolean esAdmin() {
        return this.esAdministrador;
    }

    /**
     * Convierte este usuario en administrador
     */
    public void hacerAdministrador() {
        this.esAdministrador = true;
    }

    /**
     * Quita privilegios de administrador
     */
    public void quitarAdministrador() {
        this.esAdministrador = false;
    }

    /**
     * Valida que el username sea válido
     */
    public static boolean usernameValido(String username) {
        return username != null &&
                username.length() >= 3 &&
                username.length() <= 20 &&
                username.matches("[a-zA-Z0-9_]+");
    }

    /**
     * Valida que la contraseña sea segura
     */
    public static boolean passwordValida(String password) {
        return password != null && password.length() >= 4;
    }

    /**
     * Valida que el email tenga formato correcto
     */
    public static boolean emailValido(String email) {
        if (email == null) return false;
        return email.contains("@") && email.contains(".");
    }

    /**
     * Cambia la contraseña del usuario
     */
    public void cambiarPassword(String nuevaPassword) {
        if (passwordValida(nuevaPassword)) {
            this.password = nuevaPassword;
        }
    }

    // ============ GETTERS Y SETTERS ============

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (usernameValido(username)) {
            this.username = username;
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (passwordValida(password)) {
            this.password = password;
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (emailValido(email)) {
            this.email = email;
        }
    }

    public boolean isEsAdministrador() {
        return esAdministrador;
    }

    public void setEsAdministrador(boolean esAdministrador) {
        this.esAdministrador = esAdministrador;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "username='" + username + '\'' +
                ", esAdmin=" + esAdministrador +
                '}';
    }
}
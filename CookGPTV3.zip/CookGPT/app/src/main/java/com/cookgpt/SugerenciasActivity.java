package com.cookgpt;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.content.Intent;
import androidx.room.Room;
import java.util.List;
import java.util.ArrayList;

public class SugerenciasActivity extends AppCompatActivity {

    AppDatabase db;
    LinearLayout layoutRecetas;
    Button btnVolver;
    RadioGroup radioGroupTiempo;
    RadioButton radioTodos, radioMuyRapido, radioRapido, radioMedio, radioNormal, radioLargo;

    private static final int TIEMPO_MUY_RAPIDO = 5;
    private static final int TIEMPO_RAPIDO_MIN = 5;
    private static final int TIEMPO_RAPIDO_MAX = 10;
    private static final int TIEMPO_MEDIO_MIN = 10;
    private static final int TIEMPO_MEDIO_MAX = 15;
    private static final int TIEMPO_NORMAL_MIN = 15;
    private static final int TIEMPO_NORMAL_MAX = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sugerencias);

        layoutRecetas = findViewById(R.id.layoutRecetas);
        btnVolver = findViewById(R.id.btnVolverIngredientes);
        radioGroupTiempo = findViewById(R.id.radioGroupTiempo);
        radioTodos = findViewById(R.id.radioTodos);
        radioMuyRapido = findViewById(R.id.radioMuyRapido);
        radioRapido = findViewById(R.id.radioRapido);
        radioMedio = findViewById(R.id.radioMedio);
        radioNormal = findViewById(R.id.radioNormal);
        radioLargo = findViewById(R.id.radioLargo);

        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "cookgpt-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        // Por defecto mostrar todas las recetas
        radioTodos.setChecked(true);
        mostrarRecetasPosibles();

        // Listener para cambios en el filtro
        radioGroupTiempo.setOnCheckedChangeListener((group, checkedId) -> {
            layoutRecetas.removeAllViews();
            mostrarRecetasPosibles();
        });

        btnVolver.setOnClickListener(v -> {
            Intent i = new Intent(SugerenciasActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }

    private void mostrarRecetasPosibles() {
        List<Ingrediente> ingredientesDisponibles = db.ingredienteDao().getDisponibles();
        List<Utensilio> utensiliosDisponibles = db.utensilioDao().getDisponibles();
        List<Receta> todasLasRecetas = db.recetaDao().getAll();

        List<String> nombresIngredientes = new ArrayList<>();
        for (Ingrediente ing : ingredientesDisponibles) {
            nombresIngredientes.add(ing.nombre.toLowerCase());
        }

        List<String> nombresUtensilios = new ArrayList<>();
        for (Utensilio ut : utensiliosDisponibles) {
            nombresUtensilios.add(ut.nombre.toLowerCase());
        }

        boolean hayRecetasPosibles = false;

        for (Receta receta : todasLasRecetas) {
            if (puedeHacerReceta(receta, nombresIngredientes, nombresUtensilios) &&
                    cumpleFiltroTiempo(receta)) {
                hayRecetasPosibles = true;
                agregarRecetaAlLayout(receta);
            }
        }

        if (!hayRecetasPosibles) {
            TextView txtNoRecetas = new TextView(this);
            txtNoRecetas.setText("No hay recetas posibles con los ingredientes, utensilios y tiempo seleccionados.\n\nIntenta cambiar el filtro de tiempo o agregar más ingredientes.");
            txtNoRecetas.setTextSize(16);
            txtNoRecetas.setPadding(20, 20, 20, 20);
            layoutRecetas.addView(txtNoRecetas);
        }
    }

    private boolean cumpleFiltroTiempo(Receta receta) {
        int filtroSeleccionado = radioGroupTiempo.getCheckedRadioButtonId();

        if (filtroSeleccionado == R.id.radioTodos) {
            return true;
        } else if (filtroSeleccionado == R.id.radioMuyRapido) {
            return receta.tiempo < TIEMPO_MUY_RAPIDO;
        } else if (filtroSeleccionado == R.id.radioRapido) {
            return receta.tiempo >= TIEMPO_RAPIDO_MIN && receta.tiempo < TIEMPO_RAPIDO_MAX;
        } else if (filtroSeleccionado == R.id.radioMedio) {
            return receta.tiempo >= TIEMPO_MEDIO_MIN && receta.tiempo < TIEMPO_MEDIO_MAX;
        } else if (filtroSeleccionado == R.id.radioNormal) {
            return receta.tiempo >= TIEMPO_NORMAL_MIN && receta.tiempo <= TIEMPO_NORMAL_MAX;
        } else if (filtroSeleccionado == R.id.radioLargo) {
            return receta.tiempo > TIEMPO_NORMAL_MAX;
        }

        return true;
    }

    private boolean puedeHacerReceta(Receta receta, List<String> ingredientesDisponibles, List<String> utensiliosDisponibles) {
        String[] ingredientesNecesarios = receta.ingredientes.toLowerCase().split(",");
        for (String ingrediente : ingredientesNecesarios) {
            if (!ingredientesDisponibles.contains(ingrediente.trim())) {
                return false;
            }
        }

        if (receta.utensiliosNecesarios != null && !receta.utensiliosNecesarios.isEmpty()) {
            String[] utensiliosNecesarios = receta.utensiliosNecesarios.toLowerCase().split(",");
            for (String utensilio : utensiliosNecesarios) {
                if (!utensiliosDisponibles.contains(utensilio.trim())) {
                    return false;
                }
            }
        }

        return true;
    }

    private void agregarRecetaAlLayout(Receta receta) {
        Button btnReceta = new Button(this);
        btnReceta.setText(receta.nombre + " (" + receta.tiempo + " min)");
        btnReceta.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        btnReceta.setOnClickListener(v -> {
            Intent intent = new Intent(SugerenciasActivity.this, DetalleRecetaActivity.class);
            intent.putExtra("nombre", receta.nombre);
            intent.putExtra("pasos", receta.pasos);
            intent.putExtra("tiempo", receta.tiempo);
            intent.putExtra("ingredientes", receta.ingredientes);
            startActivity(intent);
        });

        layoutRecetas.addView(btnReceta);
    }
}